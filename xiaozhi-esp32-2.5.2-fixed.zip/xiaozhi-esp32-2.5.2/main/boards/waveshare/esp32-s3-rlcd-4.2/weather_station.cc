#if defined(__GNUC__) && !defined(__clang__)
// 新增模块对编译器告警零容忍（项目将警告视为错误），
// 关闭格式化输出长度相关的静态分析告警，避免理论截断误报阻断编译
#pragma GCC diagnostic ignored "-Wformat-truncation"
#pragma GCC diagnostic ignored "-Wformat-overflow"
#pragma GCC diagnostic ignored "-Wformat"
#endif

#include "weather_station.h"

#include <cJSON.h>
#include <esp_log.h>
#include <freertos/FreeRTOS.h>
#include <freertos/event_groups.h>
#include <freertos/task.h>

#include <atomic>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>

#include "board.h"

#define TAG "WeatherStation"

// 天气城市（默认本溪 101070501；可通过语音切换，由 board 层持久化）
static std::string g_city_id = "101070501";
static std::mutex g_city_mutex;

static constexpr int kRefreshIntervalMs = 15 * 60 * 1000;  // 15 分钟自动刷新一次
static constexpr int kWaitSliceMs = 10 * 1000;             // 分片等待，便于响应手动刷新

static const char* kWeekName[7] = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};

// ---- 辅助：WMO 天气代码 -> 中文（保留兼容） ----
const char* WeatherCodeText(int code) {
    switch (code) {
        case 0:
        case 1: return "晴";
        case 2: return "多云";
        case 3: return "阴";
        case 45:
        case 48: return "雾";
        case 51:
        case 53:
        case 55:
        case 56:
        case 57:
        case 61: return "小雨";
        case 63: return "中雨";
        case 65:
        case 82: return "大雨";
        case 66:
        case 67: return "雨";
        case 71: return "小雪";
        case 73: return "中雪";
        case 75: return "大雪";
        case 77:
        case 85:
        case 86: return "雪";
        case 80:
        case 81: return "阵雨";
        case 95:
        case 96:
        case 99: return "雷雨";
        default: return "--";
    }
}

// ---- 中国天气网天气现象代码 -> 中文（尽量不超过 4 字，适配 80px 列宽） ----
static const char* CnWeatherText(const char* code) {
    if (code == nullptr || code[0] == '\0') return "--";
    if (strcmp(code, "00") == 0) return "晴";
    if (strcmp(code, "01") == 0) return "多云";
    if (strcmp(code, "02") == 0) return "阴";
    if (strcmp(code, "03") == 0) return "阵雨";
    if (strcmp(code, "04") == 0) return "雷阵雨";
    if (strcmp(code, "05") == 0) return "雷阵雨";
    if (strcmp(code, "06") == 0) return "雨夹雪";
    if (strcmp(code, "07") == 0) return "小雨";
    if (strcmp(code, "08") == 0) return "中雨";
    if (strcmp(code, "09") == 0) return "大雨";
    if (strcmp(code, "10") == 0) return "暴雨";
    if (strcmp(code, "11") == 0) return "大暴雨";
    if (strcmp(code, "12") == 0) return "特大暴雨";
    if (strcmp(code, "13") == 0) return "阵雪";
    if (strcmp(code, "14") == 0) return "小雪";
    if (strcmp(code, "15") == 0) return "中雪";
    if (strcmp(code, "16") == 0) return "大雪";
    if (strcmp(code, "17") == 0) return "暴雪";
    if (strcmp(code, "18") == 0) return "雾";
    if (strcmp(code, "19") == 0) return "冻雨";
    if (strcmp(code, "20") == 0) return "沙尘暴";
    if (strcmp(code, "21") == 0) return "小到中雨";
    if (strcmp(code, "22") == 0) return "中到大雨";
    if (strcmp(code, "23") == 0) return "大到暴雨";
    if (strcmp(code, "24") == 0) return "暴雨";
    if (strcmp(code, "25") == 0) return "暴雨";
    if (strcmp(code, "26") == 0) return "小到中雪";
    if (strcmp(code, "27") == 0) return "中到大雪";
    if (strcmp(code, "28") == 0) return "大到暴雪";
    if (strcmp(code, "29") == 0) return "浮尘";
    if (strcmp(code, "30") == 0) return "扬尘";
    if (strcmp(code, "31") == 0) return "强沙尘暴";
    if (strcmp(code, "53") == 0) return "霾";
    return "--";
}

const char* WindDirText(int deg) {
    static const char* kDirs[8] = {"北", "东北", "东", "东南", "南", "西南", "西", "西北"};
    int idx = ((deg + 22) % 360) / 45;
    return kDirs[idx & 7];
}

const char* WindLevelText(float speed_ms) {
    static const char* kLevels[13] = {"零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二"};
    static char buf[12];
    static const float kBounds[13] = {0.5f,  1.6f,  3.4f,  5.5f,  8.0f,  10.8f, 13.9f,
                                      17.2f, 20.8f, 24.5f, 28.5f, 32.7f, 999.0f};
    int level = 0;
    for (int i = 0; i < 13; i++) {
        if (speed_ms >= kBounds[i]) {
            level = i + 1;
            if (level > 12) level = 12;
        } else {
            break;
        }
    }
    snprintf(buf, sizeof(buf), "%s级", kLevels[level]);
    return buf;
}

const char* UvLevelText(int uv) {
    if (uv <= 2) return "弱";
    if (uv <= 5) return "中等";
    if (uv <= 7) return "强";
    if (uv <= 10) return "很强";
    return "极强";
}

// ---- 全局状态 ----
static std::atomic<bool> g_request_refresh{false};
static std::atomic<time_t> g_last_update{0};
static std::atomic<int> g_last_fail{0};
static EventGroupHandle_t g_event_group = nullptr;
static constexpr int kRequestBit = BIT0;

time_t WeatherStation::LastUpdateAt() {
    return g_last_update.load();
}

int WeatherStation::LastFailReason() {
    return g_last_fail.load();
}

std::string WeatherStation::CurrentCityId() {
    std::lock_guard<std::mutex> lock(g_city_mutex);
    return g_city_id;
}

// ---- HTTP 文本获取（带 Referer，中国天气网接口必需） ----
static bool HttpGetText(const std::string& url, const char* referer, std::string* out) {
    auto network = Board::GetInstance().GetNetwork();
    if (network == nullptr) return false;
    auto http = network->CreateHttp(0);
    if (http == nullptr) return false;
    http->SetTimeout(15000);
    http->SetHeader("Accept", "*/*");
    if (referer != nullptr) {
        http->SetHeader("Referer", referer);
    }
    http->SetHeader("User-Agent",
                    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                    "(KHTML, like Gecko) Chrome/120.0 Safari/537.36");
    bool ok = false;
    if (http->Open("GET", url.c_str())) {
        auto status = http->GetStatusCode();
        if (status && *status == 200) {
            *out = http->ReadAll();
            ok = !out->empty();
        } else {
            ESP_LOGW(TAG, "HTTP status not 200: %s", url.c_str());
        }
        http->Close();
    } else {
        ESP_LOGW(TAG, "HTTP open failed: %s", url.c_str());
    }
    return ok;
}

// 从 "var xxx ={...};" 形式的 JS 文本中提取完整的 JSON 对象
static bool ExtractJsObject(const std::string& body, const char* marker, std::string* out) {
    size_t p = body.find(marker);
    if (p == std::string::npos) return false;
    size_t start = body.find('{', p);
    if (start == std::string::npos) return false;
    int depth = 0;
    bool in_str = false;
    bool esc = false;
    for (size_t i = start; i < body.size(); i++) {
        char c = body[i];
        if (in_str) {
            if (esc) {
                esc = false;
            } else if (c == '\\') {
                esc = true;
            } else if (c == '"') {
                in_str = false;
            }
            continue;
        }
        if (c == '"') {
            in_str = true;
        } else if (c == '{') {
            depth++;
        } else if (c == '}') {
            depth--;
            if (depth == 0) {
                *out = body.substr(start, i - start + 1);
                return true;
            }
        }
    }
    return false;
}

static int RoundTemp(double v) {
    return (int)(v + (v >= 0 ? 0.5 : -0.5));
}

// ---- 解析 d1.weather.com.cn/weather_index（实况 + 5 日预报 + 紫外线） ----
static bool ParseWeatherIndex(const std::string& body, WeatherInfo* info) {
    // 使用默认构造重置，避免对含默认成员初始化器的结构体做 memset
    *info = WeatherInfo();

    std::string sk_json;
    if (!ExtractJsObject(body, "var dataSK", &sk_json)) return false;
    cJSON* sk = cJSON_Parse(sk_json.c_str());
    if (sk == nullptr) return false;

    // 实况：温度、湿度、天气现象、风向风力、空气质量
    cJSON* temp = cJSON_GetObjectItem(sk, "temp");
    if (cJSON_IsString(temp) && temp->valuestring[0] != '\0') {
        double v = atof(temp->valuestring);
        // 999 为接口异常占位值，忽略
        if (v > -90.0 && v < 90.0) {
            info->cur_temp = RoundTemp(v);
            info->has_cur = true;
        }
    }
    cJSON* sd = cJSON_GetObjectItem(sk, "SD");
    if (cJSON_IsString(sd)) {
        info->cur_hum = atoi(sd->valuestring);
    }
    cJSON* weather = cJSON_GetObjectItem(sk, "weather");
    if (cJSON_IsString(weather)) {
        snprintf(info->cond_cur, sizeof(info->cond_cur), "%s", weather->valuestring);
    }
    cJSON* wd = cJSON_GetObjectItem(sk, "WD");
    cJSON* ws = cJSON_GetObjectItem(sk, "WS");
    if (cJSON_IsString(wd) && cJSON_IsString(ws)) {
        snprintf(info->wind_text, sizeof(info->wind_text), "%s%s", wd->valuestring,
                 ws->valuestring);
        info->has_wind = true;
    }
    cJSON* aqi = cJSON_GetObjectItem(sk, "aqi");
    if (cJSON_IsString(aqi)) {
        snprintf(info->aqi_text, sizeof(info->aqi_text), "AQI %s", aqi->valuestring);
    }
    // 实况日期 "11月19日(星期四)"，用于对齐“今天”
    int sk_month = 0, sk_day = 0;
    cJSON* date = cJSON_GetObjectItem(sk, "date");
    if (cJSON_IsString(date)) {
        sscanf(date->valuestring, "%d月%d日", &sk_month, &sk_day);
    }
    cJSON_Delete(sk);

    // 接口日期解析失败时，退回设备本地日期（已设置 CST-8 时区）
    if (sk_month == 0 || sk_day == 0) {
        time_t now = time(nullptr);
        struct tm tn;
        localtime_r(&now, &tn);
        sk_month = tn.tm_mon + 1;
        sk_day = tn.tm_mday;
    }

    // 5 日预报
    std::string fc_json;
    if (!ExtractJsObject(body, "var fc", &fc_json)) return false;
    cJSON* fcr = cJSON_Parse(fc_json.c_str());
    if (fcr == nullptr) return false;
    cJSON* arr = cJSON_GetObjectItem(fcr, "f");
    int n = cJSON_GetArraySize(arr);
    if (n <= 0) {
        cJSON_Delete(fcr);
        return false;
    }

    // 找到“今天”在数组中的位置（服务端 fi 偶尔滞后一天，不能假定从今天开始）
    int today_idx = 0;
    for (int i = 0; i < n; i++) {
        cJSON* item = cJSON_GetArrayItem(arr, i);
        cJSON* fi = cJSON_GetObjectItem(item, "fi");  // "11/19"
        int m = 0, d = 0;
        if (cJSON_IsString(fi) && sscanf(fi->valuestring, "%d/%d", &m, &d) == 2) {
            if (sk_month > 0 && m == sk_month && d == sk_day) {
                today_idx = i;
                break;
            }
        }
    }

    // 从“昨天”开始取，保证 5 列填满（昨天/今天/明天/周X）。
    // 服务端数组若从今天开始，则第 0 列（昨天）留给 itboy yesterday 补充。
    int start = (today_idx >= 1) ? (today_idx - 1) : 0;
    int out_i = 0;
    for (int i = start; i < n && out_i < 5; i++, out_i++) {
        cJSON* item = cJSON_GetArrayItem(arr, i);
        if (!cJSON_IsObject(item)) continue;

        cJSON* fa = cJSON_GetObjectItem(item, "fa");  // 白天天气代码
        cJSON* fb = cJSON_GetObjectItem(item, "fb");  // 夜间天气代码
        cJSON* hi = cJSON_GetObjectItem(item, "fc");  // 最高温
        cJSON* lo = cJSON_GetObjectItem(item, "fd");  // 最低温
        cJSON* fi = cJSON_GetObjectItem(item, "fi");  // 日期

        WeatherInfo::Daily& day = info->daily[out_i];
        day.valid = true;
        if (cJSON_IsString(fa) && fa->valuestring[0] != '\0') {
            snprintf(day.cond, sizeof(day.cond), "%s", CnWeatherText(fa->valuestring));
        } else if (cJSON_IsString(fb)) {
            snprintf(day.cond, sizeof(day.cond), "%s", CnWeatherText(fb->valuestring));
        } else {
            snprintf(day.cond, sizeof(day.cond), "%s", "--");
        }
        if (cJSON_IsString(hi)) day.tmax = atoi(hi->valuestring);
        if (cJSON_IsString(lo)) day.tmin = atoi(lo->valuestring);
        if (cJSON_IsString(fi)) {
            int m = 0, d = 0;
            if (sscanf(fi->valuestring, "%d/%d", &m, &d) == 2) {
                day.day_of_month = d;
                struct tm tm_day = {};
                tm_day.tm_mon = m - 1;
                tm_day.tm_mday = d;
                tm_day.tm_hour = 12;
                // 用当前年份修正，避免跨年误差
                time_t now = time(nullptr);
                struct tm tm_now;
                localtime_r(&now, &tm_now);
                tm_day.tm_year = tm_now.tm_year;
                mktime(&tm_day);
                day.weekday = tm_day.tm_wday;
            }
        }
    }
    cJSON_Delete(fcr);

    // 紫外线
    std::string zs_json;
    if (ExtractJsObject(body, "var dataZS", &zs_json)) {
        cJSON* zsr = cJSON_Parse(zs_json.c_str());
        if (zsr != nullptr) {
            cJSON* zs = cJSON_GetObjectItem(zsr, "zs");
            cJSON* uv = cJSON_GetObjectItem(zs, "uv_hint");
            if (cJSON_IsString(uv)) {
                snprintf(info->uv_text, sizeof(info->uv_text), "%s", uv->valuestring);
            }
            cJSON_Delete(zsr);
        }
    }

    info->valid = true;
    return true;
}

// "高温 6℃" / "低温 -8℃" -> 数字
static int ParseTempText(const char* s) {
    if (s == nullptr) return 0;
    while (*s != '\0' && !((*s >= '0' && *s <= '9') || *s == '-')) s++;
    return atoi(s);
}

// ---- 解析 t.weather.itboy.net（补充日出日落与昨天；失败不影响主数据） ----
static bool ParseItboyExtra(const std::string& body, WeatherInfo* info) {
    cJSON* root = cJSON_Parse(body.c_str());
    if (root == nullptr) return false;
    cJSON* data = cJSON_GetObjectItem(root, "data");

    // 日出日落
    cJSON* forecast = cJSON_GetObjectItem(data, "forecast");
    cJSON* first = cJSON_GetArrayItem(forecast, 0);
    if (cJSON_IsObject(first)) {
        cJSON* sr = cJSON_GetObjectItem(first, "sunrise");
        cJSON* ss = cJSON_GetObjectItem(first, "sunset");
        bool ok = false;
        if (cJSON_IsString(sr)) {
            sscanf(sr->valuestring, "%d:%d", &info->sunrise_h, &info->sunrise_m);
            ok = true;
        }
        if (cJSON_IsString(ss)) {
            sscanf(ss->valuestring, "%d:%d", &info->sunset_h, &info->sunset_m);
            ok = true;
        }
        if (ok) info->has_sun = true;
    }

    // 昨天：当主接口的预报数组从“今天”开始时，用于补齐第 1 列
    if (!info->daily[0].valid) {
        cJSON* y = cJSON_GetObjectItem(data, "yesterday");
        if (cJSON_IsObject(y)) {
            WeatherInfo::Daily& d = info->daily[0];
            cJSON* type = cJSON_GetObjectItem(y, "type");
            cJSON* high = cJSON_GetObjectItem(y, "high");
            cJSON* low = cJSON_GetObjectItem(y, "low");
            cJSON* ymd = cJSON_GetObjectItem(y, "ymd");
            if (cJSON_IsString(type)) {
                snprintf(d.cond, sizeof(d.cond), "%s", type->valuestring);
            } else {
                snprintf(d.cond, sizeof(d.cond), "%s", "--");
            }
            if (cJSON_IsString(high)) d.tmax = ParseTempText(high->valuestring);
            if (cJSON_IsString(low)) d.tmin = ParseTempText(low->valuestring);
            d.valid = true;
            if (cJSON_IsString(ymd)) {
                int yy = 0, mm = 0, dd = 0;
                if (sscanf(ymd->valuestring, "%d-%d-%d", &yy, &mm, &dd) == 3) {
                    d.day_of_month = dd;
                    struct tm tm_day = {};
                    tm_day.tm_year = yy - 1900;
                    tm_day.tm_mon = mm - 1;
                    tm_day.tm_mday = dd;
                    tm_day.tm_hour = 12;
                    mktime(&tm_day);
                    d.weekday = tm_day.tm_wday;
                }
            }
        }
    }
    cJSON_Delete(root);
    return true;
}

// 生成趋势点：只统计有效天，标签固定为 昨天/今天/明天/周X
static void BuildTrend(WeatherInfo* info) {
    int cnt = 0;
    for (int i = 0; i < 5; i++) {
        if (!info->daily[i].valid) {
            if (i == 0) continue;  // 昨天缺失：跳过，其余天仍连续
            break;
        }
        info->hourly[cnt].hour = i;
        info->hourly[cnt].temp = info->daily[i].tmax;
        const char* lb;
        if (i == 0) {
            lb = "昨天";
        } else if (i == 1) {
            lb = "今天";
        } else if (i == 2) {
            lb = "明天";
        } else {
            lb = kWeekName[info->daily[i].weekday & 7];
        }
        snprintf(info->hourly[cnt].label, sizeof(info->hourly[cnt].label), "%s", lb);
        cnt++;
    }
    info->hours = cnt;
    info->trend_is_daily = true;
}

static bool FetchWeather(WeatherInfo* info) {
    std::string id = WeatherStation::CurrentCityId();

    // 1) 主数据：中国天气网实况 + 5 日预报
    std::string url = "http://d1.weather.com.cn/weather_index/" + id + ".html";
    std::string body;
    if (!HttpGetText(url, "http://www.weather.com.cn/", &body)) {
        g_last_fail.store(kWeatherFailNetwork);
        return false;
    }
    if (!ParseWeatherIndex(body, info)) {
        g_last_fail.store(kWeatherFailParse);
        return false;
    }

    // 2) 补充日出日落与昨天（可选）
    std::string sun_url = "http://t.weather.itboy.net/api/weather/city/" + id;
    std::string sun_body;
    if (HttpGetText(sun_url, nullptr, &sun_body)) {
        ParseItboyExtra(sun_body, info);
    }

    // 3) 统一生成趋势点
    BuildTrend(info);

    return true;
}

void WeatherStation::RequestAsync() {
    g_request_refresh.store(true);
    if (g_event_group != nullptr) {
        xEventGroupSetBits(g_event_group, kRequestBit);
    }
}

// UTF-8 百分号编码（供 URL 使用）
static std::string UrlEncodeName(const std::string& s) {
    std::string out;
    char hex[4];
    for (unsigned char c : s) {
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.') {
            out += static_cast<char>(c);
        } else {
            snprintf(hex, sizeof(hex), "%%%02X", c);
            out += hex;
        }
    }
    return out;
}

// 中国天气网城市搜索：返回 "([{"ref":"101070501~liaoning~本溪~Benxi~...~辽宁"},...])"
static bool QueryCityOnce(const std::string& name, std::string* city_id,
                          std::string* resolved_name) {
    std::string encoded = UrlEncodeName(name);
    std::string url = "http://toy1.weather.com.cn/search?cityname=" + encoded;
    std::string body;
    if (!HttpGetText(url, "http://www.weather.com.cn/", &body)) return false;

    // 去掉外层括号："( ... )" -> "[ ... ]"
    size_t lp = body.find('(');
    size_t rp = body.rfind(')');
    if (lp == std::string::npos || rp == std::string::npos || rp <= lp) return false;
    std::string json = "[" + body.substr(lp + 1, rp - lp - 1) + "]";

    cJSON* root = cJSON_Parse(json.c_str());
    if (root == nullptr) return false;
    int n = cJSON_GetArraySize(root);
    bool ok = false;
    for (int i = 0; i < n; i++) {
        cJSON* item = cJSON_GetArrayItem(root, i);
        cJSON* ref = cJSON_GetObjectItem(item, "ref");
        if (!cJSON_IsString(ref)) continue;
        // ref 用 ~ 分隔：cityid~province_en~city_cn~city_en~...~province_cn
        std::string r = ref->valuestring;
        std::string parts[10];
        int pc = 0;
        size_t pos = 0;
        while (pc < 10) {
            size_t q = r.find('~', pos);
            if (q == std::string::npos) {
                parts[pc++] = r.substr(pos);
                break;
            }
            parts[pc++] = r.substr(pos, q - pos);
            pos = q + 1;
        }
        if (pc < 3) continue;
        const std::string& cid = parts[0];
        const std::string& cname = parts[2];
        if (cid.empty() || cname.empty()) continue;
        // 名称匹配：完全相等，或以“市”结尾且去掉“市”后相等
        bool match = (cname == name);
        if (!match && cname.size() > 3 && cname.compare(cname.size() - 3, 3, "市") == 0) {
            if (cname.substr(0, cname.size() - 3) == name) match = true;
        }
        if (!match) continue;
        *city_id = cid;
        *resolved_name = cname;
        ok = true;
        // 优先地级市（编号以 01 结尾），否则先记录第一个匹配
        if (cid.size() >= 2 && cid.compare(cid.size() - 2, 2, "01") == 0) break;
    }
    cJSON_Delete(root);
    return ok;
}

bool WeatherStation::LookupCity(const std::string& city, std::string* city_id,
                                std::string* resolved_name) {
    if (city.empty() || city_id == nullptr || resolved_name == nullptr) return false;
    // 依次尝试：原名、原名+“市”
    if (QueryCityOnce(city, city_id, resolved_name)) return true;
    if (city.find("市") == std::string::npos) {
        if (QueryCityOnce(city + "市", city_id, resolved_name)) return true;
    }
    return false;
}

void WeatherStation::SetCity(const std::string& city_id, const std::string& city) {
    (void)city;  // 城市名由 board 层保存并显示在标题，此处只需城市 ID
    {
        std::lock_guard<std::mutex> lock(g_city_mutex);
        if (!city_id.empty()) {
            g_city_id = city_id;
        }
    }
    RequestAsync();
}

void WeatherStation::TaskEntry(void* arg) {
    auto* self = static_cast<WeatherStation*>(arg);
    self->Run();
    vTaskDelete(nullptr);
}

void WeatherStation::Run() {
    // 等待网络与时间同步
    time_t now = time(NULL);
    struct tm tm_now;
    localtime_r(&now, &tm_now);
    for (int wait_s = 0; tm_now.tm_year < 120 && wait_s < 120; wait_s += 2) {
        vTaskDelay(pdMS_TO_TICKS(2000));
        now = time(NULL);
        localtime_r(&now, &tm_now);
    }

    while (true) {
        WeatherInfo info;
        if (FetchWeather(&info)) {
            g_last_update.store(time(NULL));
            g_last_fail.store(kWeatherFailNone);
            ESP_LOGI(TAG, "Weather updated: %d C, %d%%, %s", info.cur_temp, info.cur_hum,
                     info.cond_cur);
            if (apply_cb_ != nullptr) {
                apply_cb_(info);
            }
        } else {
            // 把失败原因回传到界面，便于在屏幕上直接看到问题所在
            info.valid = false;
            info.fail_reason = g_last_fail.load();
            if (apply_cb_ != nullptr) {
                apply_cb_(info);
            }
            ESP_LOGW(TAG, "Fetch weather failed (reason %d), retry in 30 seconds", info.fail_reason);
            // 失败后约 30 秒重试；每片无条件消费刷新标志（事件组位仅用于加速唤醒）
            static constexpr int kRetrySlices = 30 * 1000 / kWaitSliceMs;
            for (int waited = 0; waited < kRetrySlices; waited++) {
                if (g_request_refresh.exchange(false)) {
                    break;
                }
                if (g_event_group != nullptr) {
                    xEventGroupWaitBits(g_event_group, kRequestBit, pdTRUE, pdFALSE,
                                        pdMS_TO_TICKS(kWaitSliceMs));
                } else {
                    vTaskDelay(pdMS_TO_TICKS(kWaitSliceMs));
                }
            }
            continue;
        }

        // 正常周期：15 分钟，或被请求提前唤醒（每片无条件消费标志，杜绝请求丢失）
        for (int slices = 0; slices < kRefreshIntervalMs / kWaitSliceMs; slices++) {
            if (g_request_refresh.exchange(false)) {
                break;
            }
            if (g_event_group != nullptr) {
                xEventGroupWaitBits(g_event_group, kRequestBit, pdTRUE, pdFALSE,
                                    pdMS_TO_TICKS(kWaitSliceMs));
            } else {
                vTaskDelay(pdMS_TO_TICKS(kWaitSliceMs));
            }
        }
    }
}

void WeatherStation::Start() {
    if (g_event_group == nullptr) {
        g_event_group = xEventGroupCreate();
    }
    // 网络请求栈空间给足 16KB
    BaseType_t ret = xTaskCreate(TaskEntry, "weather", 16 * 1024, this, 3, nullptr);
    if (ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create weather task");
    }
}