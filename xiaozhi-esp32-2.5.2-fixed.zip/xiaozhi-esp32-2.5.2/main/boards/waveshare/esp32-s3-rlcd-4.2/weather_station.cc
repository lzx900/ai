#if defined(__GNUC__) && !defined(__clang__)
// 新增模块对编译器告警零容忍（项目将警告视为错误），
// 关闭格式化输出长度相关的静态分析告警，避免理论截断误报阻断编译
#pragma GCC diagnostic ignored "-Wformat-truncation"
#pragma GCC diagnostic ignored "-Wformat-overflow"
#pragma GCC diagnostic ignored "-Wformat"
#endif

#include "weather_station.h"

#include <cJSON.h>
#include <esp_log.h>
#include <freertos/FreeRTOS.h>
#include <freertos/event_groups.h>
#include <freertos/task.h>

#include <atomic>
#include <cstring>
#include <ctime>
#include <memory>
#include <mutex>
#include <string>

#include "board.h"

#define TAG "WeatherStation"

// 天气城市（默认本溪市坐标；可通过语音切换，由 board 层持久化）
static double g_lat = 41.2976;
static double g_lon = 123.7669;
static std::string g_city_name = "本溪";
static std::mutex g_city_mutex;

// 根据当前城市坐标构建天气 API 地址（坐标系仅本文件线程与互斥锁保护）
static std::string BuildWeatherUrl() {
    double lat, lon;
    {
        std::lock_guard<std::mutex> lock(g_city_mutex);
        lat = g_lat;
        lon = g_lon;
    }
    char url[512];
    snprintf(url, sizeof(url),
             "https://api.open-meteo.com/v1/forecast?"
             "latitude=%.4f&longitude=%.4f&timezone=Asia%%2FShanghai&past_days=1&forecast_days=4"
             "&wind_speed_unit=ms&cell_selection=nearest"
             "&current=temperature_2m%%2Crelative_humidity_2m%%2Capparent_temperature"
             "&daily=weather_code%%2Ctemperature_2m_max%%2Ctemperature_2m_min%%2Cprecipitation_probability_max%%2Csunrise%%2Csunset%%"
             "2Cuv_index_max%%2Cwind_direction_10m_dominant%%2Cwind_speed_10m_max"
             "&hourly=temperature_2m%%2Cprecipitation_probability",
             lat, lon);
    return std::string(url);
}

static constexpr int kRefreshIntervalMs = 15 * 60 * 1000;  // 15 分钟自动刷新一次
static constexpr int kWaitSliceMs = 10 * 1000;             // 分片等待，便于响应手动刷新

const char* WeatherCodeText(int code) {
    switch (code) {
        case 0: return "晴";
        case 1: return "晴";
        case 2: return "多云";
        case 3: return "阴";
        case 45:
        case 48: return "雾";
        case 51:
        case 53:
        case 55:
        case 56:
        case 57:
        case 61: return "小雨";
        case 63: return "中雨";
        case 65:
        case 82: return "大雨";
        case 66:
        case 67: return "雨";
        case 71: return "小雪";
        case 73: return "中雪";
        case 75: return "大雪";
        case 77:
        case 85:
        case 86: return "雪";
        case 80:
        case 81: return "阵雨";
        case 95:
        case 96:
        case 99: return "雷雨";
        default: return "--";
    }
}

const char* WindDirText(int deg) {
    static const char* kDirs[8] = {"北", "东北", "东", "东南", "南", "西南", "西", "西北"};
    int idx = ((deg + 22) % 360) / 45;
    return kDirs[idx & 7];
}

const char* WindLevelText(float speed_ms) {
    static const char* kLevels[13] = {"零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十", "十一", "十二"};
    static char buf[12];
    static const float kBounds[13] = {0.5f,  1.6f,  3.4f,  5.5f,  8.0f,  10.8f, 13.9f,
                                      17.2f, 20.8f, 24.5f, 28.5f, 32.7f, 999.0f};
    int level = 0;
    for (int i = 0; i < 13; i++) {
        if (speed_ms >= kBounds[i]) {
            level = i + 1;
            if (level > 12) level = 12;
        } else {
            break;
        }
    }
    snprintf(buf, sizeof(buf), "%s级", kLevels[level]);
    return buf;
}

const char* UvLevelText(int uv) {
    if (uv <= 2) return "弱";
    if (uv <= 5) return "中等";
    if (uv <= 7) return "强";
    if (uv <= 10) return "很强";
    return "极强";
}

// ---- 全局状态 ----
static std::atomic<bool> g_request_refresh{false};
static std::atomic<time_t> g_last_update{0};
static EventGroupHandle_t g_event_group = nullptr;
static constexpr int kRequestBit = BIT0;

time_t WeatherStation::LastUpdateAt() {
    return g_last_update.load();
}

// ---- JSON 解析 ----
static bool ParseWeatherJson(const char* body, size_t len, WeatherInfo* info) {
    std::unique_ptr<cJSON, decltype(&cJSON_Delete)> root(cJSON_ParseWithLength(body, len), cJSON_Delete);
    if (root == nullptr) return false;

    std::memset(info, 0, sizeof(*info));

    // 日历时间（判断"今天"）
    struct tm tm_now;
    time_t now = time(NULL);
    localtime_r(&now, &tm_now);

    // 当前实况
    cJSON* cur = cJSON_GetObjectItem(root.get(), "current");
    if (cur != nullptr) {
        cJSON* t = cJSON_GetObjectItem(cur, "temperature_2m");
        cJSON* h = cJSON_GetObjectItem(cur, "relative_humidity_2m");
        if (cJSON_IsNumber(t)) {
            info->cur_temp = (int)(t->valuedouble + (t->valuedouble >= 0 ? 0.5 : -0.5));
            info->has_cur = true;
        }
        if (cJSON_IsNumber(h)) {
            info->cur_hum = (int)h->valueint;
        }
    }

    // 五日预报
    cJSON* daily = cJSON_GetObjectItem(root.get(), "daily");
    if (daily == nullptr) return false;
    cJSON* d_time = cJSON_GetObjectItem(daily, "time");
    cJSON* d_code = cJSON_GetObjectItem(daily, "weather_code");
    cJSON* d_tmax = cJSON_GetObjectItem(daily, "temperature_2m_max");
    cJSON* d_tmin = cJSON_GetObjectItem(daily, "temperature_2m_min");
    cJSON* d_pop = cJSON_GetObjectItem(daily, "precipitation_probability_max");
    cJSON* d_sunrise = cJSON_GetObjectItem(daily, "sunrise");
    cJSON* d_sunset = cJSON_GetObjectItem(daily, "sunset");
    cJSON* d_uv = cJSON_GetObjectItem(daily, "uv_index_max");
    cJSON* d_wdir = cJSON_GetObjectItem(daily, "wind_direction_10m_dominant");
    cJSON* d_wspd = cJSON_GetObjectItem(daily, "wind_speed_10m_max");

    int daily_count = cJSON_GetArraySize(d_time);
    if (daily_count <= 2) return false;

    char today_str[24];
    {
        // 用 strftime 构造 "YYYY-MM-DD"，避免 snprintf 截断类告警
        struct tm tm_today = tm_now;
        strftime(today_str, sizeof(today_str), "%Y-%m-%d", &tm_today);
    }
    int today_idx = -1;
    for (int i = 0; i < daily_count; i++) {
        cJSON* item = cJSON_GetArrayItem(d_time, i);
        if (cJSON_IsString(item) && strcmp(item->valuestring, today_str) == 0) {
            today_idx = i;
            break;
        }
    }
    if (today_idx < 0) today_idx = daily_count > 1 ? 1 : 0;

    int cnt = daily_count < 5 ? daily_count : 5;
    for (int i = 0; i < cnt; i++) {
        cJSON* t_item = cJSON_GetArrayItem(d_time, i);
        if (!cJSON_IsString(t_item)) continue;
        int y, m, d;
        if (sscanf(t_item->valuestring, "%d-%d-%d", &y, &m, &d) != 3) continue;
        struct tm tm_day = {};
        tm_day.tm_year = y - 1900;
        tm_day.tm_mon = m - 1;
        tm_day.tm_mday = d;
        tm_day.tm_hour = 12;
        time_t day_ts = mktime(&tm_day);
        struct tm tm_w;
        localtime_r(&day_ts, &tm_w);
        info->daily[i].day_of_month = d;
        info->daily[i].weekday = tm_w.tm_wday;
        info->daily[i].valid = true;

        cJSON* c = cJSON_GetArrayItem(d_code, i);
        cJSON* hi = cJSON_GetArrayItem(d_tmax, i);
        cJSON* lo = cJSON_GetArrayItem(d_tmin, i);
        cJSON* pop = cJSON_GetArrayItem(d_pop, i);
        if (cJSON_IsNumber(c)) info->daily[i].code = c->valueint;
        if (cJSON_IsNumber(hi)) info->daily[i].tmax = (int)(hi->valuedouble + 0.5);
        if (cJSON_IsNumber(lo)) info->daily[i].tmin = (int)(lo->valuedouble + 0.5);
        if (cJSON_IsNumber(pop)) info->daily[i].precip = (int)pop->valueint;
    }

    if (today_idx >= 0 && today_idx < cnt) {
        info->daily[today_idx].valid = true;
    }

    // 辅助参数（取今天）
    cJSON* sr = cJSON_GetArrayItem(d_sunrise, today_idx);
    cJSON* ss = cJSON_GetArrayItem(d_sunset, today_idx);
    cJSON* uv = cJSON_GetArrayItem(d_uv, today_idx);
    cJSON* wdir = cJSON_GetArrayItem(d_wdir, today_idx);
    cJSON* wspd = cJSON_GetArrayItem(d_wspd, today_idx);
    if (cJSON_IsString(sr)) {
        sscanf(sr->valuestring + 11, "%d:%d", &info->sunrise_h, &info->sunrise_m);
        info->has_sun = true;
    }
    if (cJSON_IsString(ss)) {
        sscanf(ss->valuestring + 11, "%d:%d", &info->sunset_h, &info->sunset_m);
        info->has_sun = true;
    }
    if (cJSON_IsNumber(uv)) info->uv = (int)(uv->valuedouble + 0.5);
    if (cJSON_IsNumber(wdir)) info->wind_deg = (int)wdir->valuedouble;
    if (cJSON_IsNumber(wspd)) {
        info->wind_speed = (float)wspd->valuedouble;
        info->has_wind = true;
    }

    // 逐小时趋势：首尾固定 00:00 与 23:00，中间均匀取 4 个点（05/09/14/18 时，
    // 23 小时无法被 5 等分，取最接近的整点，间隔 5-4-5-4-5 小时）
    static constexpr int kTrendHours[6] = {0, 5, 9, 14, 18, 23};
    cJSON* hourly = cJSON_GetObjectItem(root.get(), "hourly");
    if (hourly != nullptr) {
        cJSON* h_time = cJSON_GetObjectItem(hourly, "time");
        cJSON* h_temp = cJSON_GetObjectItem(hourly, "temperature_2m");
        cJSON* h_pop = cJSON_GetObjectItem(hourly, "precipitation_probability");
        int h_count = cJSON_GetArraySize(h_time);
        // 今天日期前缀 "YYYY-MM-DDT"（strftime 构造，避免 snprintf 告警）
        char today_prefix[16];
        strftime(today_prefix, sizeof(today_prefix), "%Y-%m-%dT", &tm_now);
        for (int k = 0; k < 6; k++) {
            char want_key[24];
            snprintf(want_key, sizeof(want_key), "%s%02d:00", today_prefix, kTrendHours[k]);
            for (int i = 0; i < h_count; i++) {
                cJSON* item = cJSON_GetArrayItem(h_time, i);
                if (cJSON_IsString(item) && strcmp(item->valuestring, want_key) == 0) {
                    cJSON* t = cJSON_GetArrayItem(h_temp, i);
                    cJSON* p = cJSON_GetArrayItem(h_pop, i);
                    info->hourly[k].hour = kTrendHours[k];
                    if (cJSON_IsNumber(t)) info->hourly[k].temp = (int)(t->valuedouble + 0.5);
                    if (cJSON_IsNumber(p)) info->hourly[k].precip = (int)p->valueint;
                    info->hours = k + 1;
                    break;
                }
            }
        }
    }

    info->valid = true;
    return true;
}

static bool FetchWeather(WeatherInfo* info) {
    auto network = Board::GetInstance().GetNetwork();
    if (network == nullptr) return false;
    auto http = network->CreateHttp(0);
    if (http == nullptr) return false;
    http->SetTimeout(15000);
    http->SetHeader("Accept", "application/json");
    bool ok = false;
    std::string url = BuildWeatherUrl();
    if (http->Open("GET", url.c_str())) {
        auto status = http->GetStatusCode();
        if (status && *status == 200) {
            std::string body = http->ReadAll();
            http->Close();
            if (body.size() > 100) {
                ok = ParseWeatherJson(body.c_str(), body.size(), info);
            }
        } else {
            ESP_LOGW(TAG, "Weather API status not 200");
            http->Close();
        }
    } else {
        ESP_LOGW(TAG, "Open weather API failed");
    }
    return ok;
}

void WeatherStation::RequestAsync() {
    g_request_refresh.store(true);
    if (g_event_group != nullptr) {
        xEventGroupSetBits(g_event_group, kRequestBit);
    }
}

bool WeatherStation::LookupCity(const std::string& city, double* lat, double* lon,
                                std::string* resolved_name) {
    if (city.empty() || lat == nullptr || lon == nullptr || resolved_name == nullptr) return false;
    // 城市名 URL 编码（UTF-8 逐字节百分号编码）
    std::string encoded;
    char hex[4];
    for (unsigned char c : city) {
        if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9') ||
            c == '-' || c == '_' || c == '.') {
            encoded += static_cast<char>(c);
        } else {
            snprintf(hex, sizeof(hex), "%%%02X", c);
            encoded += hex;
        }
    }
    char url[192];
    snprintf(url, sizeof(url),
             "https://geocoding-api.open-meteo.com/v1/search?name=%s&count=1&language=zh&format=json",
             encoded.c_str());
    auto network = Board::GetInstance().GetNetwork();
    if (network == nullptr) return false;
    auto http = network->CreateHttp(0);
    if (http == nullptr) return false;
    http->SetTimeout(15000);
    http->SetHeader("Accept", "application/json");
    bool ok = false;
    if (http->Open("GET", url)) {
        auto status = http->GetStatusCode();
        if (status && *status == 200) {
            std::string body = http->ReadAll();
            http->Close();
            cJSON* root = cJSON_ParseWithLength(body.c_str(), body.size());
            if (root != nullptr) {
                cJSON* results = cJSON_GetObjectItem(root, "results");
                if (cJSON_IsArray(results) && cJSON_GetArraySize(results) > 0) {
                    cJSON* first = cJSON_GetArrayItem(results, 0);
                    cJSON* la = cJSON_GetObjectItem(first, "latitude");
                    cJSON* lo = cJSON_GetObjectItem(first, "longitude");
                    cJSON* nm = cJSON_GetObjectItem(first, "name");
                    if (cJSON_IsNumber(la) && cJSON_IsNumber(lo)) {
                        *lat = la->valuedouble;
                        *lon = lo->valuedouble;
                        if (cJSON_IsString(nm) && nm->valuestring != nullptr &&
                            nm->valuestring[0] != '\0') {
                            *resolved_name = nm->valuestring;
                        } else {
                            *resolved_name = city;
                        }
                        ok = true;
                    }
                }
                cJSON_Delete(root);
            }
        } else {
            ESP_LOGW(TAG, "Geocoding API status not 200");
            http->Close();
        }
    } else {
        ESP_LOGW(TAG, "Open geocoding API failed");
    }
    return ok;
}

void WeatherStation::SetLocation(double lat, double lon, const std::string& city) {
    {
        std::lock_guard<std::mutex> lock(g_city_mutex);
        g_lat = lat;
        g_lon = lon;
        if (!city.empty()) {
            g_city_name = city;
        }
    }
    RequestAsync();
}

void WeatherStation::TaskEntry(void* arg) {
    auto* self = static_cast<WeatherStation*>(arg);
    self->Run();
    vTaskDelete(nullptr);
}

void WeatherStation::Run() {
    // 等待网络与时间同步
    time_t now = time(NULL);
    struct tm tm_now;
    localtime_r(&now, &tm_now);
    for (int wait_s = 0; tm_now.tm_year < 120 && wait_s < 120; wait_s += 2) {
        vTaskDelay(pdMS_TO_TICKS(2000));
        now = time(NULL);
        localtime_r(&now, &tm_now);
    }

    while (true) {
        WeatherInfo info;
        if (FetchWeather(&info)) {
            g_last_update.store(time(NULL));
            ESP_LOGI(TAG, "Weather updated");
            if (apply_cb_ != nullptr) {
                apply_cb_(info);
            }
        } else {
            ESP_LOGW(TAG, "Fetch weather failed, retry in 30 seconds");
            // 失败后约 30 秒重试；每片无条件消费刷新标志（事件组位仅用于加速唤醒，避免双通道丢失请求）
            static constexpr int kRetrySlices = 30 * 1000 / kWaitSliceMs;
            for (int waited = 0; waited < kRetrySlices; waited++) {
                if (g_request_refresh.exchange(false)) {
                    break;
                }
                if (g_event_group != nullptr) {
                    xEventGroupWaitBits(g_event_group, kRequestBit, pdTRUE, pdFALSE,
                                        pdMS_TO_TICKS(kWaitSliceMs));
                } else {
                    vTaskDelay(pdMS_TO_TICKS(kWaitSliceMs));
                }
            }
            continue;
        }

        // 正常周期：15 分钟，或被请求提前唤醒（每片无条件消费标志，杜绝请求丢失）
        for (int slices = 0; slices < kRefreshIntervalMs / kWaitSliceMs; slices++) {
            if (g_request_refresh.exchange(false)) {
                break;
            }
            if (g_event_group != nullptr) {
                xEventGroupWaitBits(g_event_group, kRequestBit, pdTRUE, pdFALSE,
                                    pdMS_TO_TICKS(kWaitSliceMs));
            } else {
                vTaskDelay(pdMS_TO_TICKS(kWaitSliceMs));
            }
        }
    }
}

void WeatherStation::Start() {
    if (g_event_group == nullptr) {
        g_event_group = xEventGroupCreate();
    }
    // HTTPS(TLS) 握手需要较大栈空间，给足 16KB 防止栈溢出
    BaseType_t ret = xTaskCreate(TaskEntry, "weather", 16 * 1024, this, 3, nullptr);
    if (ret != pdPASS) {
        ESP_LOGE(TAG, "Failed to create weather task");
    }
}
