#ifndef __CUSTOM_LCD_DISPLAY_H__
#define __CUSTOM_LCD_DISPLAY_H__

#include <driver/gpio.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <lvgl.h>

#include <memory>
#include <string>
#include <vector>

#include "lcd_display.h"
#include "lunar_calendar.h"
#include "weather_station.h"

enum ColorSelection {
    ColorBlack = 0,
    ColorWhite = 0xff
};

typedef struct {
    uint8_t mosi;
    uint8_t scl;
    uint8_t dc;
    uint8_t cs;
    uint8_t rst;
} spi_display_config_t;

// 页面索引
enum CustomPage {
    kPageMain = 0,      // 主界面：左栏工作信息 | 右上环境 + 右下备忘录
    kPageCalendar = 1,  // 日历
    kPageWeather = 2,   // 天气（本溪）
    kPageCount = 3,
};

class CustomLcdDisplay : public LcdDisplay {
private:
    /* ================= 原反射屏驱动（保持不变） ================= */
    esp_lcd_panel_io_handle_t io_handle = NULL;
    uint32_t            i2c_data_pdMS_TICKS = 0;
    uint32_t            i2c_done_pdMS_TICKS = 0;
    const char         *TAG                 = "CustomDisplay";
    int                 mosi_;
    int                 scl_;
    int                 dc_;
    int                 cs_;
    int                 rst_;
    int                 width_;
    int                 height_;
    uint8_t            *DispBuffer = NULL;
    int                 DisplayLen;
    uint16_t (*PixelIndexLUT)[300];
    uint8_t  (*PixelBitLUT  )[300];
    void InitPortraitLUT();
    void InitLandscapeLUT();
    void Set_ResetIOLevel(uint8_t level);
    void RLCD_SendCommand(uint8_t Reg);
    void RLCD_SendData(uint8_t Data);
    void RLCD_Sendbuffera(uint8_t *Data, int len);
    void RLCD_Reset(void);
    static void Lvgl_flush_cb(lv_display_t * disp, const lv_area_t * area, uint8_t * color_p);

    /* ================= 自定义三界面 ================= */
    // 中文字体（启动时为内置基础字体，assets 加载后成为 common 中文字体）
    std::shared_ptr<LvglFont> zh_font_;
    std::vector<lv_obj_t*> zh_labels_;   // 需要跟随字体更新的 label 列表
    std::shared_ptr<LvglFont> main_cjk_font_;  // 主界面内嵌 16px 中文字体

    // ---- 主界面 ----
    lv_obj_t* page_main_ = nullptr;
    lv_obj_t* main_value_[4] = {nullptr, nullptr, nullptr, nullptr};  // 任务/负责人/工作人员/气体浓度
    lv_obj_t* main_time_ = nullptr;
    lv_obj_t* main_date_ = nullptr;
    lv_obj_t* main_temp_ = nullptr;
    lv_obj_t* main_hum_ = nullptr;
    lv_obj_t* main_memo_ = nullptr;

    // ---- 日历页 ----
    lv_obj_t* page_cal_ = nullptr;
    lv_obj_t* cal_time_ = nullptr;
    lv_obj_t* cal_temp_ = nullptr;
    lv_obj_t* cal_hum_ = nullptr;
    lv_obj_t* cal_wifi_ = nullptr;
    lv_obj_t* cal_bat_ = nullptr;
    lv_obj_t* cal_bat_text_ = nullptr;
    lv_obj_t* cal_month_ = nullptr;
    lv_obj_t* cal_ganzhi_ = nullptr;
    lv_obj_t* cal_cells_[42] = {nullptr};   // 格子容器
    lv_obj_t* cal_day_labels_[42] = {nullptr};
    lv_obj_t* cal_day_bgs_[42] = {nullptr};  // 当天反显黑底
    lv_obj_t* cal_lunar_ = nullptr;
    int cal_last_today_ = -1;

    // ---- 天气页 ----
    lv_obj_t* page_wth_ = nullptr;
    lv_obj_t* wth_wifi_ = nullptr;
    lv_obj_t* wth_bat_ = nullptr;
    lv_obj_t* wth_bat_text_ = nullptr;
    lv_obj_t* wth_time_ = nullptr;
    lv_obj_t* wth_cur_ = nullptr;           // "31.1°C 28%"
    lv_obj_t* wth_city_ = nullptr;          // "本溪 天气预报"
    lv_obj_t* wth_updated_ = nullptr;       // "15:32 更新"
    lv_obj_t* wth_day_name_[5] = {nullptr};
    lv_obj_t* wth_day_code_[5] = {nullptr};
    lv_obj_t* wth_day_temp_[5] = {nullptr};
    lv_obj_t* wth_day_pop_[5] = {nullptr};
    lv_obj_t* wth_today_box_ = nullptr;
    lv_obj_t* wth_aux1_val_[4] = {nullptr};  // 日出/日落/体感/湿度
    lv_obj_t* wth_uv_val_ = nullptr;
    lv_obj_t* wth_wind_val_ = nullptr;
    lv_obj_t* wth_trend_ = nullptr;          // 折线
    lv_obj_t* wth_trend_temp_[6] = {nullptr};
    lv_obj_t* wth_trend_time_[6] = {nullptr};
    lv_point_precise_t trend_points_[6];

    // ---- 数据 ----
    std::string work_fields_[4];   // 工作信息四项
    std::string memo_;
    float sensor_temp_ = -1000;
    float sensor_hum_ = -1000;
    WeatherInfo weather_;
    int current_page_ = kPageMain;
    int last_minute_ = -1;
    int last_day_ = -1;
    int last_battery_ = -1;
    const char* last_wifi_icon_ = nullptr;

    /* ---- 构建辅助 ---- */
    lv_obj_t* CreateLabel(lv_obj_t* parent, const lv_font_t* font, const char* text,
                          int x, int y, bool zh = false);
    lv_obj_t* CreateHLine(lv_obj_t* parent, int x, int y, int w);
    lv_obj_t* CreateVLine(lv_obj_t* parent, int x, int y, int h);
    lv_obj_t* CreateTitleBar(lv_obj_t* parent, const lv_font_t* font, const char* text, int x, int y, int w, int h);
    void RegisterZh(lv_obj_t* label);

    void SetupMainPage(lv_obj_t* screen);
    void SetupCalendarPage(lv_obj_t* screen);
    void SetupWeatherPage(lv_obj_t* screen);
    void ShowPage(int page);

    void LoadPersisted();
    void PersistWork();
    void RefreshMainValues();
    void RefreshCalendar();
    void RefreshWeatherValues();
    void RefreshStatusIcons(bool force);
    void RefreshTimeLabels(struct tm* tm_now);

public:
    CustomLcdDisplay(esp_lcd_panel_io_handle_t panel_io, esp_lcd_panel_handle_t panel,
                  int width, int height, int offset_x, int offset_y,
                  bool mirror_x, bool mirror_y, bool swap_xy,
                  spi_display_config_t spiconfig, spi_host_device_t spi_host = SPI3_HOST);
    ~CustomLcdDisplay();
    void RLCD_Init();
    void RLCD_ColorClear(uint8_t color);
    void RLCD_Display();
    void RLCD_SetPixel(uint16_t x, uint16_t y, uint8_t color);

    /* ---- 界面/显示重载 ---- */
    void SetupUI() override;
    bool SetTextFont(std::shared_ptr<LvglFont> text_font) override;
    void UpdateStatusBar(bool update_all = false) override;
    void SetEmotion(const char* emotion) override;
    void SetChatMessage(const char* role, const char* content) override;
    void ShowNotification(const char* notification, int duration_ms = 3000) override;
    void ShowNotification(const std::string& notification, int duration_ms = 3000) override;

    /* ---- 界面切换 ---- */
    void SwitchPage(int offset);
    void SwitchToPage(int page);
    int current_page() const { return current_page_; }

    /* ---- 数据接口（跨线程调用时内部有显示锁） ---- */
    void SetWorkField(int field, const std::string& value);   // 0任务/1负责人/2工作人员/3气体浓度
    std::string GetWorkField(int field) const;
    void SetMemoText(const std::string& value);
    std::string GetMemoText() const { return memo_; }
    void SetSensorData(float temperature, float humidity);    // SHTC3
    void ApplyWeather(const WeatherInfo& w);
    bool HasWeather() const { return weather_.valid; }
};

#endif
