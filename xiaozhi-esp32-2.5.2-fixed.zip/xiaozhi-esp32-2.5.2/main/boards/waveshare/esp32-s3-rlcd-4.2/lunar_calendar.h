#ifndef BOARD_LUNAR_CALENDAR_H
#define BOARD_LUNAR_CALENDAR_H

// 农历计算（公历->农历、干支、生肖、中文月日）
// 数据来源: jjonline/calendar.js 的 1900-2100 lunarInfo 权威表

struct LunarDate {
    int year;    // 农历年份
    int month;   // 农历月份 1..12（非闰月编号）
    int day;     // 农历日 1..30
    bool is_leap;  // 该日是否属于闰月
};

// 公历 -> 农历（支持 1900.1.31 ~ 2100.12.31），失败返回 false
bool SolarToLunar(int y, int m, int d, LunarDate* out);

// 农历中文月日，如 "十月初九"、"闰四月十六"；闰月带"闰"前缀
void LunarToCnString(const LunarDate* ld, char* buf, int buf_size);

// 农历年干支，如 "丙午"
void LunarGanZhi(int lunar_year, char* buf, int buf_size);

// 农历年生肖，如 "马"
const char* LunarZodiac(int lunar_year);

#endif  // BOARD_LUNAR_CALENDAR_H
