#if defined(__GNUC__) && !defined(__clang__)
// 同 weather_station.cc：关闭格式化输出长度相关的静态分析告警，避免误报阻断编译
#pragma GCC diagnostic ignored "-Wformat-truncation"
#pragma GCC diagnostic ignored "-Wformat-overflow"
#pragma GCC diagnostic ignored "-Wformat"
#endif

#include "lunar_calendar.h"

#include <cstdint>
#include <cstdio>
#include <cstring>

// 农历 1900-2100 年信息表（闰月+大小月），来源 jjonline/calendar.js
// bits 0-3: 闰月月份(0=无闰月)
// bit 16: 闰月大小(1=30天)
// bit(17-m) (m=1..12): 第 m 个月大小，1=大月(30天)
static const uint32_t kLunarInfo[] = {
    0x04bd8, 0x04ae0, 0x0a570, 0x054d5, 0x0d260, 0x0d950, 0x16554, 0x056a0, 0x09ad0, 0x055d2,  // 1900-1909
    0x04ae0, 0x0a5b6, 0x0a4d0, 0x0d250, 0x1d255, 0x0b540, 0x0d6a0, 0x0ada2, 0x095b0, 0x14977,  // 1910-1919
    0x04970, 0x0a4b0, 0x0b4b5, 0x06a50, 0x06d40, 0x1ab54, 0x02b60, 0x09570, 0x052f2, 0x04970,  // 1920-1929
    0x06566, 0x0d4a0, 0x0ea50, 0x16a95, 0x05ad0, 0x02b60, 0x186e3, 0x092e0, 0x1c8d7, 0x0c950,  // 1930-1939
    0x0d4a0, 0x1d8a6, 0x0b550, 0x056a0, 0x1a5b4, 0x025d0, 0x092d0, 0x0d2b2, 0x0a950, 0x0b557,  // 1940-1949
    0x06ca0, 0x0b550, 0x15355, 0x04da0, 0x0a5b0, 0x14573, 0x052b0, 0x0a9a8, 0x0e950, 0x06aa0,  // 1950-1959
    0x0aea6, 0x0ab50, 0x04b60, 0x0aae4, 0x0a570, 0x05260, 0x0f263, 0x0d950, 0x05b57, 0x056a0,  // 1960-1969
    0x096d0, 0x04dd5, 0x04ad0, 0x0a4d0, 0x0d4d4, 0x0d250, 0x0d558, 0x0b540, 0x0b6a0, 0x195a6,  // 1970-1979
    0x095b0, 0x049b0, 0x0a974, 0x0a4b0, 0x0b27a, 0x06a50, 0x06d40, 0x0af46, 0x0ab60, 0x09570,  // 1980-1989
    0x04af5, 0x04970, 0x064b0, 0x074a3, 0x0ea50, 0x06b58, 0x05ac0, 0x0ab60, 0x096d5, 0x092e0,  // 1990-1999
    0x0c960, 0x0d954, 0x0d4a0, 0x0da50, 0x07552, 0x056a0, 0x0abb7, 0x025d0, 0x092d0, 0x0cab5,  // 2000-2009
    0x0a950, 0x0b4a0, 0x0baa4, 0x0ad50, 0x055d9, 0x04ba0, 0x0a5b0, 0x15176, 0x052b0, 0x0a930,  // 2010-2019
    0x07954, 0x06aa0, 0x0ad50, 0x05b52, 0x04b60, 0x0a6e6, 0x0a4e0, 0x0d260, 0x0ea65, 0x0d530,  // 2020-2029
    0x05aa0, 0x076a3, 0x096d0, 0x04afb, 0x04ad0, 0x0a4d0, 0x1d0b6, 0x0d250, 0x0d520, 0x0dd45,  // 2030-2039
    0x0b5a0, 0x056d0, 0x055b2, 0x049b0, 0x0a577, 0x0a4b0, 0x0aa50, 0x1b255, 0x06d20, 0x0ada0,  // 2040-2049
    0x14b63, 0x09370, 0x049f8, 0x04970, 0x064b0, 0x168a6, 0x0ea50, 0x06b20, 0x1a6c4, 0x0aae0,  // 2050-2059
    0x092e0, 0x0d2e3, 0x0c960, 0x0d557, 0x0d4a0, 0x0da50, 0x05d55, 0x056a0, 0x0a6d0, 0x055d4,  // 2060-2069
    0x052d0, 0x0a9b8, 0x0a950, 0x0b4a0, 0x0b6a6, 0x0ad50, 0x055a0, 0x0aba4, 0x0a5b0, 0x052b0,  // 2070-2079
    0x0b273, 0x06930, 0x07337, 0x06aa0, 0x0ad50, 0x14b55, 0x04b60, 0x0a570, 0x054e4, 0x0d160,  // 2080-2089
    0x0e968, 0x0d520, 0x0daa0, 0x16aa6, 0x056d0, 0x04ae0, 0x0a9d4, 0x0a2d0, 0x0d150, 0x0f252,  // 2090-2099
    0x0d520                                                                                      // 2100
};

// 农历 y 年闰月是哪个月，0 表示无闰月
static int LunarLeapMonth(int y) {
    return (int)(kLunarInfo[y - 1900] & 0xf);
}

// 农历 y 年闰月天数（无闰月返回 0）
static int LunarLeapDays(int y) {
    if (LunarLeapMonth(y)) {
        return (kLunarInfo[y - 1900] & 0x10000) ? 30 : 29;
    }
    return 0;
}

// 农历 y 年 m 月（非闰月）天数
static int LunarMonthDays(int y, int m) {
    return (kLunarInfo[y - 1900] & (0x10000 >> m)) ? 30 : 29;
}

// 农历 y 年全年天数
static int LunarYearDays(int y) {
    int sum = 348;
    for (int i = 0x8000; i > 0x8; i >>= 1) {
        if (kLunarInfo[y - 1900] & (uint32_t)i) {
            sum++;
        }
    }
    return sum + LunarLeapDays(y);
}

// 计算自 1970-01-01 起的天数（Howard Hinnant civil 算法，无时区依赖）
static int DaysFromCivil(int y, int m, int d) {
    y -= m <= 2 ? 1 : 0;
    int era = (y >= 0 ? y : y - 399) / 400;
    unsigned yoe = (unsigned)(y - era * 400);
    unsigned doy = (unsigned)((153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1);
    unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + (int)doe - 719468;
}

// 公历某月天数
static int SolarMonthDays(int y, int m) {
    static const int kDays[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    if (m == 2) {
        bool leap = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0);
        return leap ? 29 : 28;
    }
    return kDays[m - 1];
}

bool SolarToLunar(int y, int m, int d, LunarDate* out) {
    if (out == nullptr) return false;
    if (y < 1900 || y > 2100 || m < 1 || m > 12 || d < 1 || d > SolarMonthDays(y, m)) {
        return false;
    }
    // 1900-01-31 = 农历 1900 年正月初一
    int offset = DaysFromCivil(y, m, d) - DaysFromCivil(1900, 1, 31);
    if (offset < 0) return false;

    // 定位农历年
    int ly = 1900;
    while (ly < 2100 && offset >= LunarYearDays(ly)) {
        offset -= LunarYearDays(ly);
        ly++;
    }
    if (offset >= LunarYearDays(ly)) return false;  // 超出 2100

    int leap = LunarLeapMonth(ly);
    bool is_leap = false;
    int lm = 1;
    int temp = 0;
    while (lm <= 12 && offset > 0) {
        if (leap > 0 && lm == leap + 1 && !is_leap) {
            // 先处理闰月
            lm--;
            is_leap = true;
            temp = LunarLeapDays(ly);
        } else {
            temp = LunarMonthDays(ly, lm);
        }
        if (is_leap && lm == leap + 1) {
            is_leap = false;
        }
        offset -= temp;
        lm++;
    }
    // 闰月导致下标重叠的修正
    if (offset == 0 && leap > 0 && lm == leap + 1) {
        if (is_leap) {
            is_leap = false;
        } else {
            is_leap = true;
            lm--;
        }
    }
    if (offset < 0) {
        offset += temp;
        lm--;
    }

    out->year = ly;
    out->month = lm;
    out->day = offset + 1;
    out->is_leap = is_leap;
    return true;
}

static const char* kMonthCn[] = {"正", "二", "三", "四", "五", "六", "七", "八", "九", "十", "冬", "腊"};
static const char* kDayTens[] = {"初", "十", "廿", "三"};
static const char* kDayDigits[] = {"一", "二", "三", "四", "五", "六", "七", "八", "九", "十"};

void LunarToCnString(const LunarDate* ld, char* buf, int buf_size) {
    if (ld == nullptr || buf == nullptr || buf_size <= 0) return;
    if (ld->month < 1 || ld->month > 12 || ld->day < 1 || ld->day > 30) {
        snprintf(buf, buf_size, "--");
        return;
    }
    char day[8];
    if (ld->day == 10) {
        snprintf(day, sizeof(day), "初十");
    } else if (ld->day == 20) {
        snprintf(day, sizeof(day), "二十");
    } else if (ld->day == 30) {
        snprintf(day, sizeof(day), "三十");
    } else {
        snprintf(day, sizeof(day), "%s%s", kDayTens[ld->day / 10], kDayDigits[ld->day % 10 - 1]);
    }
    if (ld->is_leap) {
        snprintf(buf, buf_size, "闰%s月%s", kMonthCn[ld->month - 1], day);
    } else {
        snprintf(buf, buf_size, "%s月%s", kMonthCn[ld->month - 1], day);
    }
}

static const char* kGan[] = {"甲", "乙", "丙", "丁", "戊", "己", "庚", "辛", "壬", "癸"};
static const char* kZhi[] = {"子", "丑", "寅", "卯", "辰", "巳", "午", "未", "申", "酉", "戌", "亥"};

void LunarGanZhi(int lunar_year, char* buf, int buf_size) {
    if (buf == nullptr || buf_size <= 0) return;
    snprintf(buf, buf_size, "%s%s", kGan[(lunar_year - 4) % 10], kZhi[(lunar_year - 4) % 12]);
}

const char* LunarZodiac(int lunar_year) {
    static const char* kAnimals[] = {"鼠", "牛", "虎", "兔", "龙", "蛇", "马", "羊", "猴", "鸡", "狗", "猪"};
    return kAnimals[(lunar_year - 4) % 12];
}
