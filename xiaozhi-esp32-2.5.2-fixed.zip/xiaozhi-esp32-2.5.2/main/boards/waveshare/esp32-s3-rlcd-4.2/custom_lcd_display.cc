#include <vector>
#include <cstring>
#include <cstdio>
#include <ctime>
#include <memory>

#include <freertos/FreeRTOS.h>
#include <freertos/task.h>
#include <esp_lcd_panel_io.h>
#include <esp_log.h>
#include <esp_err.h>

#include <material_symbols.h>
#include <cbin_font.h>

#include "custom_lcd_display.h"
#include "lcd_display.h"
#include "lvgl_theme.h"
#include "esp_lvgl_port.h"
#include "assets/lang_config.h"
#include "settings.h"
#include "config.h"
#include "board.h"
#include "application.h"

// 数字/图标字体（来自 xiaozhi-fonts 组件，按需链接）
LV_FONT_DECLARE(font_noto_sans_basic_16_4);
LV_FONT_DECLARE(font_noto_sans_basic_14_1);
LV_FONT_DECLARE(font_material_symbols_16_4);

// 主界面内嵌 16px 中文字体数据（由 font_data.c 提供，见 SetupUI 创建 LvglCBinFont）
extern "C" const uint8_t font_noto_common_16_4_data[];

static const lv_font_t* kFontNumM = &font_noto_sans_basic_16_4;    // 16px 数字
static const lv_font_t* kFontNumS = &font_noto_sans_basic_14_1;    // 14px 数字
static const lv_font_t* kFontIcon = &font_material_symbols_16_4;   // 16px 图标

/* ==================== 反射屏驱动（微雪原版） ==================== */

void CustomLcdDisplay::Lvgl_flush_cb(lv_display_t * disp, const lv_area_t * area, uint8_t * color_p)
{
    assert(disp != NULL);
    CustomLcdDisplay *Disp = (CustomLcdDisplay *)lv_display_get_user_data(disp);
    uint16_t *buffer = (uint16_t *)color_p;
  	for(int y = area->y1; y <= area->y2; y++)
  	{
  	 	for(int x = area->x1; x <= area->x2; x++)
  	 	{
  	 	   	uint8_t color = (*buffer < 0x7fff) ? ColorBlack : ColorWhite;
  	 	   	Disp->RLCD_SetPixel(x,y,color);
  	 	   	buffer++;
  	 	}
  	}
   	Disp->RLCD_Display();
	lv_disp_flush_ready(disp);
}

CustomLcdDisplay::CustomLcdDisplay(esp_lcd_panel_io_handle_t panel_io,
esp_lcd_panel_handle_t panel,
int width,
int height,
int offset_x,
int offset_y,
bool mirror_x,
bool mirror_y,
bool swap_xy,
spi_display_config_t spiconfig,
spi_host_device_t spi_host) : LcdDisplay(panel_io, panel, width, height),
mosi_(spiconfig.mosi),
scl_(spiconfig.scl),
dc_(spiconfig.dc),
cs_(spiconfig.cs),
rst_(spiconfig.rst),
width_(width),
height_(height)
{
	ESP_LOGI(TAG, "Initialize SPI");
	esp_err_t        ret;
    spi_bus_config_t buscfg   = {};
    int              transfer = width_ * height_;
    buscfg.miso_io_num                   = -1;
    buscfg.mosi_io_num                   = mosi_;
    buscfg.sclk_io_num                   = scl_;
    buscfg.quadwp_io_num                 = -1;
    buscfg.quadhd_io_num                 = -1;
    buscfg.max_transfer_sz               = transfer;
    ret                                  = spi_bus_initialize(spi_host, &buscfg, SPI_DMA_CH_AUTO);
    ESP_ERROR_CHECK(ret);
    esp_lcd_panel_io_spi_config_t io_config = {};
    io_config.dc_gpio_num = static_cast<gpio_num_t>(dc_);
    io_config.cs_gpio_num = static_cast<gpio_num_t>(cs_);
    io_config.pclk_hz = 40 * 1000 * 1000;
    io_config.lcd_cmd_bits = 8;
    io_config.lcd_param_bits = 8;
    io_config.spi_mode = 0;
    io_config.trans_queue_depth = 7;
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_spi((esp_lcd_spi_bus_handle_t)spi_host, &io_config, &io_handle));
    gpio_config_t gpio_conf = {};
    gpio_conf.intr_type     = GPIO_INTR_DISABLE;
    gpio_conf.mode          = GPIO_MODE_OUTPUT;
    gpio_conf.pin_bit_mask  = (0x1ULL << rst_);
    gpio_conf.pull_down_en  = GPIO_PULLDOWN_DISABLE;
    gpio_conf.pull_up_en    = GPIO_PULLUP_ENABLE;
    ESP_ERROR_CHECK_WITHOUT_ABORT(gpio_config(&gpio_conf));
    Set_ResetIOLevel(1);

    DisplayLen                = transfer >> 3; //(1byte 8ipex)
    DispBuffer                = (uint8_t *) heap_caps_malloc(DisplayLen, MALLOC_CAP_SPIRAM);
    assert(DispBuffer);
	PixelIndexLUT = (uint16_t (*)[300])heap_caps_malloc(transfer * sizeof(uint16_t), MALLOC_CAP_SPIRAM);
	PixelBitLUT   = (uint8_t (*)[300])heap_caps_malloc(transfer * sizeof(uint8_t), MALLOC_CAP_SPIRAM);
    assert(PixelIndexLUT);
    assert(PixelBitLUT);
    if(width_ == 400) {
        InitLandscapeLUT();
    } else {
        InitPortraitLUT();
    }

    ESP_LOGI(TAG, "Initialize LVGL library");
    lv_init();
    lvgl_port_cfg_t port_cfg = ESP_LVGL_PORT_INIT_CONFIG();
    port_cfg.task_priority   = 2;
    port_cfg.timer_period_ms = 50;
    lvgl_port_init(&port_cfg);
    lvgl_port_lock(0);

    display_ = lv_display_create(width, height); /* 以水平和垂直分辨率（像素）进行基本初始化 */
    lv_display_set_flush_cb(display_, Lvgl_flush_cb);
    lv_display_set_user_data(display_, this);
	size_t lvgl_buffer_size = LV_COLOR_FORMAT_GET_SIZE(LV_COLOR_FORMAT_RGB565) * transfer;
	uint8_t *lvgl_buffer1 = (uint8_t *) heap_caps_malloc(lvgl_buffer_size, MALLOC_CAP_SPIRAM);
    assert(lvgl_buffer1);
    lv_display_set_buffers(display_, lvgl_buffer1, NULL, lvgl_buffer_size, LV_DISPLAY_RENDER_MODE_PARTIAL);

    ESP_LOGI(TAG, "RLCD init");
    RLCD_Init();

    lvgl_port_unlock();
    if (display_ == nullptr) {
        ESP_LOGE(TAG, "Failed to add display");
        return;
    }

    // Note: SetupUI() should be called by Application::Initialize(), not in constructor
    // to ensure lvgl objects are created after the display is fully initialized.
}

CustomLcdDisplay::~CustomLcdDisplay() {
}

void CustomLcdDisplay::InitPortraitLUT() {
    uint16_t W4 = width_ >> 2;
    for (uint16_t y = 0; y < height_; y++)
    {
        uint16_t byte_y = y >> 1;
        uint8_t  local_y = y & 1;
        for (uint16_t x = 0; x < width_; x++)
        {
            uint16_t byte_x = x >> 2;
            uint8_t  local_x = x & 3;

            uint32_t index = byte_y * W4 + byte_x;
            uint8_t bit = 7 - ((local_x << 1) | local_y);

            PixelIndexLUT[x][y] = index;
            PixelBitLUT  [x][y] = (1 << bit);
        }
    }
}

void CustomLcdDisplay::InitLandscapeLUT() {
    uint16_t H4 = height_ >> 2;
    for (uint16_t y = 0; y < height_; y++)
    {
        uint16_t inv_y = height_ - 1 - y;
        uint16_t block_y = inv_y >> 2;
        uint8_t  local_y  = inv_y & 3;
        for (uint16_t x = 0; x < width_; x++)
        {
            uint16_t byte_x = x >> 1;
            uint8_t  local_x = x & 1;

            uint32_t index = byte_x * H4 + block_y;
            uint8_t bit = 7 - ((local_y << 1) | local_x);

            PixelIndexLUT[x][y] = index;
            PixelBitLUT  [x][y] = (1 << bit);
        }
    }
}

void CustomLcdDisplay::Set_ResetIOLevel(uint8_t level) {
    gpio_set_level((gpio_num_t) rst_, level ? 1 : 0);
}

void CustomLcdDisplay::RLCD_SendCommand(uint8_t Reg) {
    ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io_handle, Reg, NULL, 0));
}

void CustomLcdDisplay::RLCD_SendData(uint8_t Data) {
    ESP_ERROR_CHECK(esp_lcd_panel_io_tx_param(io_handle, -1, &Data, 1));
}

void CustomLcdDisplay::RLCD_Sendbuffera(uint8_t *Data, int len) {
    ESP_ERROR_CHECK(esp_lcd_panel_io_tx_color(io_handle, -1, Data, len));
}

void CustomLcdDisplay::RLCD_Reset(void) {
    Set_ResetIOLevel(1);
    vTaskDelay(pdMS_TO_TICKS(50));
    Set_ResetIOLevel(0);
    vTaskDelay(pdMS_TO_TICKS(20));
    Set_ResetIOLevel(1);
    vTaskDelay(pdMS_TO_TICKS(50));
}

void CustomLcdDisplay::RLCD_ColorClear(uint8_t color) {
    memset(DispBuffer, color, DisplayLen);
}

void CustomLcdDisplay::RLCD_Init() {
    RLCD_Reset();

    RLCD_SendCommand(0xD6);  // NVM Load Control
	RLCD_SendData(0x17);
	RLCD_SendData(0x02);

	RLCD_SendCommand(0xD1); //Booster Enable
	RLCD_SendData(0x01);

	RLCD_SendCommand(0xC0); //Gate Voltage Control
	RLCD_SendData(0x11);
	RLCD_SendData(0x04);

	RLCD_SendCommand(0xC1); //VSHP Setting
	RLCD_SendData(0x69);
	RLCD_SendData(0x69);
	RLCD_SendData(0x69);
	RLCD_SendData(0x69);

	RLCD_SendCommand(0xC2);
	RLCD_SendData(0x19);
	RLCD_SendData(0x19);
	RLCD_SendData(0x19);
	RLCD_SendData(0x19);

	RLCD_SendCommand(0xC4);
	RLCD_SendData(0x4B);
	RLCD_SendData(0x4B);
	RLCD_SendData(0x4B);
	RLCD_SendData(0x4B);

	RLCD_SendCommand(0xC5);
	RLCD_SendData(0x19);
	RLCD_SendData(0x19);
	RLCD_SendData(0x19);
	RLCD_SendData(0x19);

	RLCD_SendCommand(0xD8);
	RLCD_SendData(0x80);
	RLCD_SendData(0xE9);

	RLCD_SendCommand(0xB2);
	RLCD_SendData(0x02);

	RLCD_SendCommand(0xB3);
	RLCD_SendData(0xE5);
	RLCD_SendData(0xF6);
	RLCD_SendData(0x05);
	RLCD_SendData(0x46);
	RLCD_SendData(0x77);
	RLCD_SendData(0x77);
	RLCD_SendData(0x77);
	RLCD_SendData(0x77);
	RLCD_SendData(0x76);
	RLCD_SendData(0x45);

	RLCD_SendCommand(0xB4);
	RLCD_SendData(0x05);
	RLCD_SendData(0x46);
	RLCD_SendData(0x77);
	RLCD_SendData(0x77);
	RLCD_SendData(0x77);
	RLCD_SendData(0x77);
	RLCD_SendData(0x76);
	RLCD_SendData(0x45);

	RLCD_SendCommand(0x62);
	RLCD_SendData(0x32);
	RLCD_SendData(0x03);
	RLCD_SendData(0x1F);

	RLCD_SendCommand(0xB7);
	RLCD_SendData(0x13);

	RLCD_SendCommand(0xB0);
	RLCD_SendData(0x64);

	RLCD_SendCommand(0x11);
	vTaskDelay(pdMS_TO_TICKS(200));
	RLCD_SendCommand(0xC9);
	RLCD_SendData(0x00);

	RLCD_SendCommand(0x36);
	RLCD_SendData(0x48);

	RLCD_SendCommand(0x3A);
	RLCD_SendData(0x11);

	RLCD_SendCommand(0xB9);
	RLCD_SendData(0x20);

	RLCD_SendCommand(0xB8);
	RLCD_SendData(0x29);

	RLCD_SendCommand(0x21);

	RLCD_SendCommand(0x2A);
	RLCD_SendData(0x12);
	RLCD_SendData(0x2A);

	RLCD_SendCommand(0x2B);
	RLCD_SendData(0x00);
	RLCD_SendData(0xC7);

	RLCD_SendCommand(0x35);
	RLCD_SendData(0x00);

	RLCD_SendCommand(0xD0);
	RLCD_SendData(0xFF);

	RLCD_SendCommand(0x38);
	RLCD_SendCommand(0x29);

    RLCD_ColorClear(ColorWhite);
}

void CustomLcdDisplay::RLCD_SetPixel(uint16_t x, uint16_t y, uint8_t color) {
    uint32_t idx = PixelIndexLUT[x][y];
    uint8_t  mask = PixelBitLUT[x][y];

    uint8_t *p = &DispBuffer[idx];

    if (color)
        *p |= mask;
    else
        *p &= ~mask;
}

void CustomLcdDisplay::RLCD_Display() {
    RLCD_SendCommand(0x2A);     // Column Address Set
  	RLCD_SendData(0x12);
  	RLCD_SendData(0x2A);

  	RLCD_SendCommand(0x2B);     // Page Address Set
  	RLCD_SendData(0x00);
  	RLCD_SendData(0xC7);

  	RLCD_SendCommand(0x2c);     // Page Address Set

	RLCD_Sendbuffera(DispBuffer,DisplayLen);
}

/* ==================== 三界面 UI ==================== */

static const char* kWorkTitle = "工作信息";
static const char* kMemoTitle = "备忘录";
static const char* kWorkPrefix[4] = {"任务：", "负责人：", "工作人员：", "气体浓度："};
static const char* kWeekCn[7] = {"日", "一", "二", "三", "四", "五", "六"};

void CustomLcdDisplay::RegisterZh(lv_obj_t* label) {
    zh_labels_.push_back(label);
}

lv_obj_t* CustomLcdDisplay::CreateLabel(lv_obj_t* parent, const lv_font_t* font,
                                        const char* text, int x, int y, bool zh) {
    lv_obj_t* label = lv_label_create(parent);
    if (zh && zh_font_ != nullptr) {
        lv_obj_set_style_text_font(label, zh_font_->font(), 0);
    } else if (font != nullptr) {
        lv_obj_set_style_text_font(label, font, 0);
    }
    lv_obj_set_style_text_color(label, lv_color_black(), 0);
    lv_label_set_text(label, text);
    lv_obj_set_pos(label, x, y);
    if (zh) {
        RegisterZh(label);
    }
    return label;
}

lv_obj_t* CustomLcdDisplay::CreateHLine(lv_obj_t* parent, int x, int y, int w) {
    lv_obj_t* line = lv_obj_create(parent);
    lv_obj_set_size(line, w, 1);
    lv_obj_set_pos(line, x, y);
    lv_obj_set_style_bg_color(line, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(line, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(line, 0, 0);
    lv_obj_set_style_radius(line, 0, 0);
    lv_obj_remove_flag(line, LV_OBJ_FLAG_SCROLLABLE);
    return line;
}

lv_obj_t* CustomLcdDisplay::CreateVLine(lv_obj_t* parent, int x, int y, int h) {
    lv_obj_t* line = lv_obj_create(parent);
    lv_obj_set_size(line, 1, h);
    lv_obj_set_pos(line, x, y);
    lv_obj_set_style_bg_color(line, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(line, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(line, 0, 0);
    lv_obj_set_style_radius(line, 0, 0);
    lv_obj_remove_flag(line, LV_OBJ_FLAG_SCROLLABLE);
    return line;
}

static lv_obj_t* CreatePageRoot(lv_obj_t* screen) {
    lv_obj_t* page = lv_obj_create(screen);
    lv_obj_set_size(page, 400, 300);
    lv_obj_set_pos(page, 0, 0);
    lv_obj_set_style_pad_all(page, 0, 0);
    lv_obj_set_style_border_width(page, 0, 0);
    lv_obj_set_style_radius(page, 0, 0);
    lv_obj_set_style_bg_color(page, lv_color_white(), 0);
    lv_obj_set_style_bg_opa(page, LV_OPA_COVER, 0);
    lv_obj_set_scrollbar_mode(page, LV_SCROLLBAR_MODE_OFF);
    lv_obj_remove_flag(page, LV_OBJ_FLAG_SCROLLABLE);
    return page;
}

// 反显标题条：黑底白字（字体由调用方指定，不注册 zh_labels_，主界面保持内嵌小字号）
lv_obj_t* CustomLcdDisplay::CreateTitleBar(lv_obj_t* parent, const lv_font_t* font, const char* text,
                                           int x, int y, int w, int h) {
    lv_obj_t* bar = lv_obj_create(parent);
    lv_obj_set_size(bar, w, h);
    lv_obj_set_pos(bar, x, y);
    lv_obj_set_style_bg_color(bar, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(bar, LV_OPA_COVER, 0);
    lv_obj_set_style_border_width(bar, 0, 0);
    lv_obj_set_style_radius(bar, 0, 0);
    lv_obj_set_style_pad_all(bar, 0, 0);
    lv_obj_set_scrollbar_mode(bar, LV_SCROLLBAR_MODE_OFF);
    lv_obj_remove_flag(bar, LV_OBJ_FLAG_SCROLLABLE);
    lv_obj_t* label = lv_label_create(bar);
    if (font != nullptr) lv_obj_set_style_text_font(label, font, 0);
    lv_obj_set_style_text_color(label, lv_color_white(), 0);
    lv_label_set_text(label, text);
    lv_obj_center(label);
    return bar;
}

/* ---------- 主界面：左栏工作信息(58%) | 右上环境 + 右下备忘录 ---------- */
void CustomLcdDisplay::SetupMainPage(lv_obj_t* screen) {
    page_main_ = CreatePageRoot(screen);

    // 主界面专用字体：优先内嵌 16px 中文字体，不可用时回退运行时字体
    const lv_font_t* mfont = main_cjk_font_ ? main_cjk_font_->font()
                             : (zh_font_ ? zh_font_->font() : nullptr);

    // 全屏 1px 外边框
    lv_obj_set_style_border_width(page_main_, 1, 0);
    lv_obj_set_style_border_color(page_main_, lv_color_black(), 0);

    // 垂直分隔线 x=232（左栏占 58%），右侧水平分隔线 y=170
    CreateVLine(page_main_, 232, 0, 300);
    CreateHLine(page_main_, 232, 170, 168);

    // ===== 左栏（232x300）：反显标题 + 工作信息 4 条 =====
    CreateTitleBar(page_main_, mfont, kWorkTitle, 72, 14, 88, 24);
    for (int i = 0; i < 4; i++) {
        // 「标签：内容」同行显示；每条最多 2 行，超宽自动换行并省略
        main_value_[i] = CreateLabel(page_main_, mfont, kWorkPrefix[i], 15, 52 + i * 46, false);
        lv_obj_set_width(main_value_[i], 209);
        lv_obj_set_height(main_value_[i], 40);
        lv_label_set_long_mode(main_value_[i], LV_LABEL_LONG_DOT);
    }

    // ===== 右上（168x170）：日期/时间/温度/湿度 =====
    main_date_ = CreateLabel(page_main_, mfont, "日期：----------", 244, 20, false);
    main_time_ = CreateLabel(page_main_, mfont, "时间：--:--", 244, 60, false);
    main_temp_ = CreateLabel(page_main_, mfont, "温度：--.-°C", 244, 100, false);
    main_hum_ = CreateLabel(page_main_, mfont, "湿度：--%", 244, 140, false);
    lv_obj_t* env_vals[4] = {main_date_, main_time_, main_temp_, main_hum_};
    for (int i = 0; i < 4; i++) {
        lv_obj_set_width(env_vals[i], 148);
        lv_obj_set_height(env_vals[i], 22);
        lv_label_set_long_mode(env_vals[i], LV_LABEL_LONG_DOT);
    }

    // ===== 右下（168x130）：反显标题 + 备忘录（最多 3 行） =====
    CreateTitleBar(page_main_, mfont, kMemoTitle, 280, 176, 72, 24);
    main_memo_ = CreateLabel(page_main_, mfont, "--", 244, 206, false);
    lv_obj_set_width(main_memo_, 148);
    lv_obj_set_height(main_memo_, 62);
    lv_label_set_long_mode(main_memo_, LV_LABEL_LONG_DOT);

    // ===== 左栏底部：对话状态行 =====
    main_state_ = CreateLabel(page_main_, mfont, "状态：待机", 15, 248, false);
    lv_obj_set_width(main_state_, 209);
    lv_label_set_long_mode(main_state_, LV_LABEL_LONG_DOT);
}

/* ---------- 日历页 ---------- */
void CustomLcdDisplay::SetupCalendarPage(lv_obj_t* screen) {
    page_cal_ = CreatePageRoot(screen);

    // 顶部状态栏（y0-28）
    cal_time_ = CreateLabel(page_cal_, kFontNumM, "--:--", 8, 6, false);
    cal_temp_ = CreateLabel(page_cal_, kFontNumS, "--.-C", 92, 8, false);
    cal_hum_ = CreateLabel(page_cal_, kFontNumS, "--%", 148, 8, false);
    cal_wifi_ = CreateLabel(page_cal_, kFontIcon, MATERIAL_SYMBOLS_WIFI_OFF, 302, 6, false);
    cal_bat_ = CreateLabel(page_cal_, kFontIcon, MATERIAL_SYMBOLS_BATTERY_ANDROID_0, 328, 6, false);
    cal_bat_text_ = CreateLabel(page_cal_, kFontNumS, "--%", 356, 8, false);
    cal_state_ = CreateLabel(page_cal_, nullptr, "待机", 200, 6, true);
    CreateHLine(page_cal_, 0, 28, 400);

    // 年月 + 干支
    cal_month_ = CreateLabel(page_cal_, nullptr, "----年-月", 10, 32, true);
    cal_ganzhi_ = lv_label_create(page_cal_);
    lv_obj_set_style_text_font(cal_ganzhi_, zh_font_ ? zh_font_->font() : nullptr, 0);
    lv_obj_set_style_text_color(cal_ganzhi_, lv_color_black(), 0);
    lv_label_set_text(cal_ganzhi_, "----");
    lv_obj_align(cal_ganzhi_, LV_ALIGN_TOP_RIGHT, -10, 34);
    RegisterZh(cal_ganzhi_);

    // 星期表头（y64-94）
    for (int i = 0; i < 7; i++) {
        lv_obj_t* label = lv_label_create(page_cal_);
        lv_obj_set_style_text_font(label, zh_font_ ? zh_font_->font() : nullptr, 0);
        lv_obj_set_style_text_color(label, lv_color_black(), 0);
        lv_obj_set_style_text_align(label, LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_width(label, 57);
        lv_label_set_text(label, kWeekCn[i]);
        lv_obj_set_pos(label, i * 57, 66);
        lv_obj_remove_flag(label, LV_OBJ_FLAG_SCROLLABLE);
        RegisterZh(label);
    }
    CreateHLine(page_cal_, 0, 96, 400);

    // 日期网格：6 行 x 7 列（每格 57x29，起始 y=98）
    for (int row = 0; row < 6; row++) {
        for (int col = 0; col < 7; col++) {
            int idx = row * 7 + col;
            lv_obj_t* cell = lv_obj_create(page_cal_);
            lv_obj_set_size(cell, 57, 27);
            lv_obj_set_pos(cell, col * 57, 98 + row * 27);
            lv_obj_set_style_pad_all(cell, 0, 0);
            lv_obj_set_style_border_width(cell, 0, 0);
            lv_obj_set_style_radius(cell, 0, 0);
            lv_obj_set_style_bg_opa(cell, LV_OPA_TRANSP, 0);
            lv_obj_set_scrollbar_mode(cell, LV_SCROLLBAR_MODE_OFF);
            lv_obj_remove_flag(cell, LV_OBJ_FLAG_SCROLLABLE);
            cal_cells_[idx] = cell;

            // 当天反显背景（默认隐藏）
            lv_obj_t* bg = lv_obj_create(cell);
            lv_obj_set_size(bg, 28, 22);
            lv_obj_center(bg);
            lv_obj_set_style_bg_color(bg, lv_color_black(), 0);
            lv_obj_set_style_bg_opa(bg, LV_OPA_COVER, 0);
            lv_obj_set_style_border_width(bg, 0, 0);
            lv_obj_set_style_radius(bg, 4, 0);
            lv_obj_add_flag(bg, LV_OBJ_FLAG_HIDDEN);
            lv_obj_remove_flag(bg, LV_OBJ_FLAG_SCROLLABLE);
            cal_day_bgs_[idx] = bg;

            // 日期数字
            lv_obj_t* label = lv_label_create(cell);
            lv_obj_set_style_text_font(label, kFontNumM, 0);
            lv_obj_set_style_text_color(label, lv_color_black(), 0);
            lv_label_set_text(label, "");
            lv_obj_center(label);
            cal_day_labels_[idx] = label;
        }
    }

    // 底部农历
    cal_lunar_ = CreateLabel(page_cal_, nullptr, "--", 10, 268, true);
}

/* ---------- 天气页（本溪） ---------- */
void CustomLcdDisplay::SetupWeatherPage(lv_obj_t* screen) {
    page_wth_ = CreatePageRoot(screen);

    // 顶部状态栏
    wth_wifi_ = CreateLabel(page_wth_, kFontIcon, MATERIAL_SYMBOLS_WIFI_OFF, 306, 2, false);
    wth_bat_ = CreateLabel(page_wth_, kFontIcon, MATERIAL_SYMBOLS_BATTERY_ANDROID_0, 332, 2, false);
    wth_bat_text_ = CreateLabel(page_wth_, kFontNumS, "--%", 358, 4, false);
    wth_state_ = CreateLabel(page_wth_, nullptr, "待机", 200, 18, true);

    // 时间 + 当前温湿度
    wth_time_ = CreateLabel(page_wth_, nullptr, "--:--", 8, 16, true);
    wth_cur_ = lv_label_create(page_wth_);
    lv_obj_set_style_text_font(wth_cur_, kFontNumS, 0);
    lv_obj_set_style_text_color(wth_cur_, lv_color_black(), 0);
    lv_label_set_text(wth_cur_, "--.-C --%");
    lv_obj_align(wth_cur_, LV_ALIGN_TOP_RIGHT, -8, 30);

    // 本溪 天气预报
    wth_city_ = CreateLabel(page_wth_, nullptr, "本溪 天气预报", 8, 52, true);
    wth_updated_ = lv_label_create(page_wth_);
    lv_obj_set_style_text_font(wth_updated_, kFontNumS, 0);
    lv_obj_set_style_text_color(wth_updated_, lv_color_black(), 0);
    lv_label_set_text(wth_updated_, "----");
    lv_obj_align(wth_updated_, LV_ALIGN_TOP_RIGHT, -8, 60);

    CreateHLine(page_wth_, 0, 88, 400);

    // 今天的黑框
    wth_today_box_ = lv_obj_create(page_wth_);
    lv_obj_set_pos(wth_today_box_, 82, 91);
    lv_obj_set_size(wth_today_box_, 76, 100);
    lv_obj_set_style_border_width(wth_today_box_, 2, 0);
    lv_obj_set_style_border_color(wth_today_box_, lv_color_black(), 0);
    lv_obj_set_style_bg_opa(wth_today_box_, LV_OPA_TRANSP, 0);
    lv_obj_set_style_radius(wth_today_box_, 0, 0);
    lv_obj_set_scrollbar_mode(wth_today_box_, LV_SCROLLBAR_MODE_OFF);
    lv_obj_remove_flag(wth_today_box_, LV_OBJ_FLAG_SCROLLABLE);

    // 五日预报 5 列
    for (int i = 0; i < 5; i++) {
        wth_day_name_[i] = lv_label_create(page_wth_);
        lv_obj_set_style_text_font(wth_day_name_[i], zh_font_ ? zh_font_->font() : nullptr, 0);
        lv_obj_set_style_text_color(wth_day_name_[i], lv_color_black(), 0);
        lv_obj_set_style_text_align(wth_day_name_[i], LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_width(wth_day_name_[i], 80);
        lv_label_set_text(wth_day_name_[i], "--");
        lv_obj_set_pos(wth_day_name_[i], i * 80, 92);
        RegisterZh(wth_day_name_[i]);

        wth_day_code_[i] = lv_label_create(page_wth_);
        lv_obj_set_style_text_font(wth_day_code_[i], zh_font_ ? zh_font_->font() : nullptr, 0);
        lv_obj_set_style_text_color(wth_day_code_[i], lv_color_black(), 0);
        lv_obj_set_style_text_align(wth_day_code_[i], LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_width(wth_day_code_[i], 80);
        lv_label_set_text(wth_day_code_[i], "--");
        lv_obj_set_pos(wth_day_code_[i], i * 80, 121);
        RegisterZh(wth_day_code_[i]);

        wth_day_temp_[i] = lv_label_create(page_wth_);
        lv_obj_set_style_text_font(wth_day_temp_[i], kFontNumM, 0);
        lv_obj_set_style_text_color(wth_day_temp_[i], lv_color_black(), 0);
        lv_obj_set_style_text_align(wth_day_temp_[i], LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_width(wth_day_temp_[i], 80);
        lv_label_set_text(wth_day_temp_[i], "--");
        lv_obj_set_pos(wth_day_temp_[i], i * 80, 156);

        wth_day_pop_[i] = lv_label_create(page_wth_);
        lv_obj_set_style_text_font(wth_day_pop_[i], kFontNumS, 0);
        lv_obj_set_style_text_color(wth_day_pop_[i], lv_color_black(), 0);
        lv_obj_set_style_text_align(wth_day_pop_[i], LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_width(wth_day_pop_[i], 80);
        lv_label_set_text(wth_day_pop_[i], "--");
        lv_obj_set_pos(wth_day_pop_[i], i * 80, 180);
    }

    // 辅助参数行 1：日出/日落/体感/湿度
    static const char* kAux1[4] = {"日出", "日落", "体感", "湿度"};
    for (int i = 0; i < 4; i++) {
        CreateLabel(page_wth_, nullptr, kAux1[i], 8 + i * 98, 196, true);
        wth_aux1_val_[i] = CreateLabel(page_wth_, kFontNumM, "----", 70 + i * 98, 201, false);
    }

    // 辅助参数行 2：紫外线 + 风向
    CreateLabel(page_wth_, nullptr, "紫外线", 8, 228, true);
    wth_uv_val_ = CreateLabel(page_wth_, nullptr, "--", 104, 228, true);
    wth_wind_val_ = lv_label_create(page_wth_);
    lv_obj_set_style_text_font(wth_wind_val_, zh_font_ ? zh_font_->font() : nullptr, 0);
    lv_obj_set_style_text_color(wth_wind_val_, lv_color_black(), 0);
    lv_label_set_text(wth_wind_val_, "--");
    lv_obj_align(wth_wind_val_, LV_ALIGN_TOP_RIGHT, -8, 228);
    RegisterZh(wth_wind_val_);

    // 逐小时趋势
    memset(trend_points_, 0, sizeof(trend_points_));
    for (int k = 0; k < 6; k++) {
        wth_trend_temp_[k] = lv_label_create(page_wth_);
        lv_obj_set_style_text_font(wth_trend_temp_[k], kFontNumS, 0);
        lv_obj_set_style_text_color(wth_trend_temp_[k], lv_color_black(), 0);
        lv_obj_set_style_text_align(wth_trend_temp_[k], LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_width(wth_trend_temp_[k], 60);
        lv_label_set_text(wth_trend_temp_[k], "--");
        lv_obj_set_pos(wth_trend_temp_[k], 3 + k * 67, 256);

        wth_trend_time_[k] = lv_label_create(page_wth_);
        lv_obj_set_style_text_font(wth_trend_time_[k], kFontNumS, 0);
        lv_obj_set_style_text_color(wth_trend_time_[k], lv_color_black(), 0);
        lv_obj_set_style_text_align(wth_trend_time_[k], LV_TEXT_ALIGN_CENTER, 0);
        lv_obj_set_width(wth_trend_time_[k], 60);
        lv_label_set_text(wth_trend_time_[k], "--:00");
        lv_obj_set_pos(wth_trend_time_[k], 3 + k * 67, 284);
    }
    wth_trend_ = lv_line_create(page_wth_);
    lv_obj_set_style_line_color(wth_trend_, lv_color_black(), 0);
    lv_obj_set_style_line_width(wth_trend_, 2, 0);
    lv_obj_set_style_line_rounded(wth_trend_, true, 0);
    lv_line_set_points(wth_trend_, trend_points_, 6);
}

/* ---------- SetupUI ---------- */
void CustomLcdDisplay::SetupUI() {
    LcdDisplay::SetupUI();
    DisplayLockGuard lock(this);

    auto lvgl_theme = static_cast<LvglTheme*>(current_theme_);
    if (lvgl_theme != nullptr) {
        zh_font_ = lvgl_theme->text_font();
    }

    // 创建内嵌 16px 中文字体（解析失败时回退为运行时字体）
    main_cjk_font_ = std::make_shared<LvglCBinFont>((void*)font_noto_common_16_4_data);
    if (main_cjk_font_->font() == nullptr) {
        ESP_LOGE(TAG, "Embedded 16px CJK font parse failed, fallback to runtime font");
        main_cjk_font_.reset();
    } else {
        // 主界面、日历、天气页统一使用内嵌 16px 中文字体
        zh_font_ = main_cjk_font_;
    }

    auto screen = lv_screen_active();

    // 隐藏默认聊天界面（保留对象，避免基类回调访问悬空指针）
    if (container_ != nullptr) lv_obj_add_flag(container_, LV_OBJ_FLAG_HIDDEN);
    if (status_bar_ != nullptr) lv_obj_add_flag(status_bar_, LV_OBJ_FLAG_HIDDEN);
    if (emoji_image_ != nullptr) lv_obj_add_flag(emoji_image_, LV_OBJ_FLAG_HIDDEN);
    if (emoji_label_ != nullptr) lv_obj_add_flag(emoji_label_, LV_OBJ_FLAG_HIDDEN);
    // low_battery_popup_ 保留，位于最上层

    SetupMainPage(screen);
    SetupCalendarPage(screen);
    SetupWeatherPage(screen);

    LoadPersisted();
    RefreshMainValues();
    RefreshCalendar();
    RefreshWeatherValues();
    ShowPage(kPageMain);
    last_minute_ = -1;
    last_day_ = -1;
}

void CustomLcdDisplay::ShowPage(int page) {
    if (page < 0 || page >= kPageCount) page = kPageMain;
    current_page_ = page;

    if (page_main_ != nullptr) {
        if (page == kPageMain) lv_obj_remove_flag(page_main_, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(page_main_, LV_OBJ_FLAG_HIDDEN);
    }
    if (page_cal_ != nullptr) {
        if (page == kPageCalendar) lv_obj_remove_flag(page_cal_, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(page_cal_, LV_OBJ_FLAG_HIDDEN);
    }
    if (page_wth_ != nullptr) {
        if (page == kPageWeather) lv_obj_remove_flag(page_wth_, LV_OBJ_FLAG_HIDDEN);
        else lv_obj_add_flag(page_wth_, LV_OBJ_FLAG_HIDDEN);
    }

    lv_obj_invalidate(lv_screen_active());
}

void CustomLcdDisplay::SwitchPage(int offset) {
    if (!setup_ui_called_) return;
    DisplayLockGuard lock(this);
    int page = ((current_page_ + offset) % kPageCount + kPageCount) % kPageCount;
    ShowPage(page);
}

void CustomLcdDisplay::SwitchToPage(int page) {
    if (!setup_ui_called_) return;
    DisplayLockGuard lock(this);
    ShowPage(page);
}

/* ---------- 系统回调重载 ---------- */
bool CustomLcdDisplay::SetTextFont(std::shared_ptr<LvglFont> text_font) {
    if (main_cjk_font_ != nullptr) {
        // 内嵌 16px 中文字体已启用，各页面统一使用，忽略运行时字体替换
        return true;
    }
    if (!LvglDisplay::SetTextFont(text_font)) {
        return false;
    }
    DisplayLockGuard lock(this);
    zh_font_ = text_font;
    const lv_font_t* font = text_font->font();
    for (auto* label : zh_labels_) {
        if (label != nullptr) {
            lv_obj_set_style_text_font(label, font, 0);
        }
    }
    lv_obj_invalidate(lv_screen_active());
    return true;
}

void CustomLcdDisplay::SetEmotion(const char* emotion) {
    // 自定义看板界面：不显示聊天表情
    (void)emotion;
}

void CustomLcdDisplay::SetChatMessage(const char* role, const char* content) {
    // 自定义看板界面：不显示聊天字幕
    (void)role;
    (void)content;
}

void CustomLcdDisplay::ShowNotification(const char* notification, int duration_ms) {
    // 自定义看板界面：不显示弹出通知（状态由语音播报）
    (void)notification;
    (void)duration_ms;
}

void CustomLcdDisplay::ShowNotification(const std::string& notification, int duration_ms) {
    ShowNotification(notification.c_str(), duration_ms);
}

/* ---------- 数据持久化 ---------- */
void CustomLcdDisplay::LoadPersisted() {
    Settings settings("workinfo", false);
    work_fields_[0] = settings.GetString("task", "");
    work_fields_[1] = settings.GetString("master", "");
    work_fields_[2] = settings.GetString("workers", "");
    work_fields_[3] = settings.GetString("gas", "");
    memo_ = settings.GetString("memo", "");
    if (work_fields_[0].empty()) work_fields_[0] = "--";
    if (work_fields_[1].empty()) work_fields_[1] = "--";
    if (work_fields_[2].empty()) work_fields_[2] = "--";
    if (work_fields_[3].empty()) work_fields_[3] = "--";
    if (memo_.empty()) memo_ = "--";
}

void CustomLcdDisplay::PersistWork() {
    Settings settings("workinfo", true);
    settings.SetString("task", work_fields_[0]);
    settings.SetString("master", work_fields_[1]);
    settings.SetString("workers", work_fields_[2]);
    settings.SetString("gas", work_fields_[3]);
    settings.SetString("memo", memo_);
}

/* ---------- 值刷新 ---------- */
void CustomLcdDisplay::RefreshMainValues() {
    if (!setup_ui_called_ || main_value_[0] == nullptr) return;
    for (int i = 0; i < 4; i++) {
        std::string text = std::string(kWorkPrefix[i]) + work_fields_[i];
        lv_label_set_text(main_value_[i], text.c_str());
    }
    lv_label_set_text(main_memo_, memo_.c_str());

    char buf[24];
    if (sensor_temp_ > -100) {
        snprintf(buf, sizeof(buf), "温度：%.1f°C", sensor_temp_);
    } else {
        snprintf(buf, sizeof(buf), "温度：--.-°C");
    }
    lv_label_set_text(main_temp_, buf);
    if (sensor_hum_ > -100) {
        snprintf(buf, sizeof(buf), "湿度：%.1f%%", sensor_hum_);
    } else {
        snprintf(buf, sizeof(buf), "湿度：--%%");
    }
    lv_label_set_text(main_hum_, buf);
}

void CustomLcdDisplay::SetWorkField(int field, const std::string& value) {
    if (field < 0 || field > 3) return;
    // 空字符串表示清除该项：恢复为占位符 "--" 并持久化
    work_fields_[field] = value.empty() ? "--" : value;
    PersistWork();
    if (!setup_ui_called_) return;
    DisplayLockGuard lock(this);
    std::string text = std::string(kWorkPrefix[field]) + work_fields_[field];
    lv_label_set_text(main_value_[field], text.c_str());
}

std::string CustomLcdDisplay::GetWorkField(int field) const {
    if (field < 0 || field > 3) return "";
    return work_fields_[field];
}

void CustomLcdDisplay::SetMemoText(const std::string& value) {
    memo_ = value;
    PersistWork();
    if (!setup_ui_called_) return;
    DisplayLockGuard lock(this);
    lv_label_set_text(main_memo_, value.empty() ? "--" : value.c_str());
}

void CustomLcdDisplay::SetSensorData(float temperature, float humidity) {
    sensor_temp_ = temperature;
    sensor_hum_ = humidity;
    if (!setup_ui_called_) return;
    DisplayLockGuard lock(this);
    char buf[24];
    snprintf(buf, sizeof(buf), "温度：%.1f°C", temperature);
    lv_label_set_text(main_temp_, buf);
    snprintf(buf, sizeof(buf), "湿度：%.1f%%", humidity);
    lv_label_set_text(main_hum_, buf);
    snprintf(buf, sizeof(buf), "%.1f°C", temperature);
    lv_label_set_text(cal_temp_, buf);
    snprintf(buf, sizeof(buf), "%d%%", (int)(humidity + 0.5));
    lv_label_set_text(cal_hum_, buf);
}

void CustomLcdDisplay::ApplyWeather(const WeatherInfo& w) {
    weather_ = w;
    if (!setup_ui_called_) return;
    DisplayLockGuard lock(this);
    RefreshWeatherValues();
}

void CustomLcdDisplay::RefreshWeatherValues() {
    if (!setup_ui_called_ || wth_city_ == nullptr) return;

    if (!weather_.valid) {
        for (int i = 0; i < 5; i++) {
            lv_label_set_text(wth_day_name_[i], "--");
            lv_label_set_text(wth_day_code_[i], "--");
            lv_label_set_text(wth_day_temp_[i], "--");
            lv_label_set_text(wth_day_pop_[i], "--");
        }
        lv_label_set_text(wth_updated_, "获取中...");
        return;
    }

    char buf[32];
    static const char* kWeekName[7] = {"周日", "周一", "周二", "周三", "周四", "周五", "周六"};
    for (int i = 0; i < 5; i++) {
        if (!weather_.daily[i].valid) continue;
        if (i == 0) {
            lv_label_set_text(wth_day_name_[i], "昨天");
        } else if (i == 1) {
            lv_label_set_text(wth_day_name_[i], "今天");
        } else {
            lv_label_set_text(wth_day_name_[i], kWeekName[weather_.daily[i].weekday]);
        }
        lv_label_set_text(wth_day_code_[i], WeatherCodeText(weather_.daily[i].code));
        snprintf(buf, sizeof(buf), "%d~%d°", weather_.daily[i].tmin, weather_.daily[i].tmax);
        lv_label_set_text(wth_day_temp_[i], buf);
        snprintf(buf, sizeof(buf), "%d%%", weather_.daily[i].precip);
        lv_label_set_text(wth_day_pop_[i], buf);
    }

    // 当前实况
    snprintf(buf, sizeof(buf), "%d°C %d%%", weather_.cur_temp, weather_.cur_hum);
    lv_label_set_text(wth_cur_, buf);

    // 辅助参数
    snprintf(buf, sizeof(buf), "%02d:%02d", weather_.sunrise_h, weather_.sunrise_m);
    lv_label_set_text(wth_aux1_val_[0], buf);
    snprintf(buf, sizeof(buf), "%02d:%02d", weather_.sunset_h, weather_.sunset_m);
    lv_label_set_text(wth_aux1_val_[1], buf);
    snprintf(buf, sizeof(buf), "%d°", weather_.apparent);
    lv_label_set_text(wth_aux1_val_[2], buf);
    snprintf(buf, sizeof(buf), "%d%%", weather_.cur_hum);
    lv_label_set_text(wth_aux1_val_[3], buf);

    lv_label_set_text(wth_uv_val_, UvLevelText(weather_.uv));

    if (weather_.has_wind) {
        snprintf(buf, sizeof(buf), "%s风%s", WindDirText(weather_.wind_deg), WindLevelText(weather_.wind_speed));
        lv_label_set_text(wth_wind_val_, buf);
    } else {
        lv_label_set_text(wth_wind_val_, "--");
    }

    // 更新时间
    time_t updated = WeatherStation::LastUpdateAt();
    if (updated > 0) {
        struct tm tm_u;
        localtime_r(&updated, &tm_u);
        char ub[16];
        strftime(ub, sizeof(ub), "%H:%M", &tm_u);
        snprintf(buf, sizeof(buf), "%s 更新", ub);
        lv_label_set_text(wth_updated_, buf);
    }

    // 逐小时趋势
    if (weather_.hours > 0) {
        int tmin = 100, tmax = -100;
        for (int k = 0; k < weather_.hours; k++) {
            if (weather_.hourly[k].temp < tmin) tmin = weather_.hourly[k].temp;
            if (weather_.hourly[k].temp > tmax) tmax = weather_.hourly[k].temp;
        }
        if (tmax - tmin < 4) {
            tmin -= 2;
            tmax += 2;
        }
        for (int k = 0; k < 6; k++) {
            lv_obj_t* temp_label = wth_trend_temp_[k];
            lv_obj_t* time_label = wth_trend_time_[k];
            if (k < weather_.hours) {
                snprintf(buf, sizeof(buf), "%d°", weather_.hourly[k].temp);
                lv_label_set_text(temp_label, buf);
                snprintf(buf, sizeof(buf), "%02d:00", weather_.hourly[k].hour);
                lv_label_set_text(time_label, buf);
                lv_obj_remove_flag(temp_label, LV_OBJ_FLAG_HIDDEN);
                lv_obj_remove_flag(time_label, LV_OBJ_FLAG_HIDDEN);
                int x = 33 + k * 67;
                int span = tmax - tmin;
                int y = 284 - (span > 0 ? (weather_.hourly[k].temp - tmin) * 12 / span : 6);
                trend_points_[k].x = x;
                trend_points_[k].y = y;
            } else {
                lv_obj_add_flag(temp_label, LV_OBJ_FLAG_HIDDEN);
                lv_obj_add_flag(time_label, LV_OBJ_FLAG_HIDDEN);
                trend_points_[k].x = trend_points_[k > 0 ? k - 1 : 0].x;
                trend_points_[k].y = trend_points_[k > 0 ? k - 1 : 0].y;
            }
        }
        lv_line_set_points(wth_trend_, trend_points_, 6);
    }
}

/* ---------- 日历刷新 ---------- */
void CustomLcdDisplay::RefreshCalendar() {
    if (!setup_ui_called_ || page_cal_ == nullptr) return;

    time_t now = time(NULL);
    struct tm tm_now;
    localtime_r(&now, &tm_now);
    int y = tm_now.tm_year + 1900;
    int m = tm_now.tm_mon + 1;
    int d = tm_now.tm_mday;

    if (tm_now.tm_year + 1900 < 2024) {
        // 时间未同步
        lv_label_set_text(cal_month_, "----年-月");
        lv_label_set_text(cal_lunar_, "--");
        return;
    }

    char buf[48];  // GCC -Wformat-truncation：干支两段 %s 最坏 38 字节，32 会误报
    snprintf(buf, sizeof(buf), "%d年%d月", y, m);
    lv_label_set_text(cal_month_, buf);

    LunarDate ld;
    if (SolarToLunar(y, m, d, &ld)) {
        char gz[16];
        LunarGanZhi(ld.year, gz, sizeof(gz));
        snprintf(buf, sizeof(buf), "%s年 %s年", gz, LunarZodiac(ld.year));
        lv_label_set_text(cal_ganzhi_, buf);

        char lunar_str[24];
        LunarToCnString(&ld, lunar_str, sizeof(lunar_str));
        lv_label_set_text(cal_lunar_, lunar_str);
    }

    // 当月第一天星期与天数
    struct tm tm_first = {};
    tm_first.tm_year = y - 1900;
    tm_first.tm_mon = m - 1;
    tm_first.tm_mday = 1;
    mktime(&tm_first);
    int first_wday = tm_first.tm_wday;  // 0=周日
    static const int kSolarDays[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    int days = kSolarDays[m];
    if (m == 2 && ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)) days = 29;

    int today_idx = -1;
    for (int i = 0; i < 42; i++) {
        int day = i - first_wday + 1;
        bool valid = (day >= 1 && day <= days);
        if (!valid) {
            lv_obj_add_flag(cal_day_labels_[i], LV_OBJ_FLAG_HIDDEN);
            lv_obj_add_flag(cal_day_bgs_[i], LV_OBJ_FLAG_HIDDEN);
            continue;
        }
        lv_obj_remove_flag(cal_day_labels_[i], LV_OBJ_FLAG_HIDDEN);
        snprintf(buf, sizeof(buf), "%d", day);
        lv_label_set_text(cal_day_labels_[i], buf);
        if (day == d) {
            today_idx = i;
            lv_obj_remove_flag(cal_day_bgs_[i], LV_OBJ_FLAG_HIDDEN);
            lv_obj_set_style_text_color(cal_day_labels_[i], lv_color_white(), 0);
        } else {
            lv_obj_add_flag(cal_day_bgs_[i], LV_OBJ_FLAG_HIDDEN);
            lv_obj_set_style_text_color(cal_day_labels_[i], lv_color_black(), 0);
        }
    }
    cal_last_today_ = today_idx;
}

/* ---------- 状态栏刷新 ---------- */
void CustomLcdDisplay::RefreshTimeLabels(struct tm* tm_now) {
    DisplayLockGuard lock(this);
    char buf[64];  // GCC -Wformat-truncation：中文前缀+最大整数宽度+星期最坏 51 字节，32 会误报
    snprintf(buf, sizeof(buf), "时间：%02d:%02d", tm_now->tm_hour, tm_now->tm_min);
    if (main_time_ != nullptr) lv_label_set_text(main_time_, buf);
    strftime(buf, sizeof(buf), "%H:%M", tm_now);
    if (cal_time_ != nullptr) lv_label_set_text(cal_time_, buf);
    if (wth_time_ != nullptr) lv_label_set_text(wth_time_, buf);

    if (tm_now->tm_yday != last_day_) {
        last_day_ = tm_now->tm_yday;
        snprintf(buf, sizeof(buf), "日期：%04d-%02d-%02d", tm_now->tm_year + 1900,
                 tm_now->tm_mon + 1, tm_now->tm_mday);
        if (main_date_ != nullptr) lv_label_set_text(main_date_, buf);
        RefreshCalendar();
    }
}

void CustomLcdDisplay::RefreshStatusIcons(bool force) {
    auto& board = Board::GetInstance();
    int level = 0;
    bool charging = false, discharging = false;
    const char* battery_icon = nullptr;
    if (board.GetBatteryLevel(level, charging, discharging)) {
        if (charging) {
            battery_icon = MATERIAL_SYMBOLS_BATTERY_ANDROID_FRAME_BOLT;
        } else {
            static const char* levels[] = {
                MATERIAL_SYMBOLS_BATTERY_ANDROID_0,
                MATERIAL_SYMBOLS_BATTERY_ANDROID_FRAME_1,
                MATERIAL_SYMBOLS_BATTERY_ANDROID_FRAME_2,
                MATERIAL_SYMBOLS_BATTERY_ANDROID_FRAME_3,
                MATERIAL_SYMBOLS_BATTERY_ANDROID_FRAME_4,
                MATERIAL_SYMBOLS_BATTERY_ANDROID_FRAME_5,
                MATERIAL_SYMBOLS_BATTERY_ANDROID_FRAME_6,
                MATERIAL_SYMBOLS_BATTERY_ANDROID_FRAME_FULL,
            };
            int idx = level <= 0 ? 0 : (level >= 100 ? 7 : 1 + ((level - 1) * 6 / 99));
            battery_icon = levels[idx];
        }
    }

    const char* wifi_icon = board.GetNetworkStateIcon();

    if (!force && level == last_battery_ && wifi_icon == last_wifi_icon_) {
        return;
    }
    last_battery_ = level;
    last_wifi_icon_ = wifi_icon;

    DisplayLockGuard lock(this);
    char buf[16];
    snprintf(buf, sizeof(buf), "%d%%", level);
    if (cal_bat_text_ != nullptr) lv_label_set_text(cal_bat_text_, buf);
    if (wth_bat_text_ != nullptr) lv_label_set_text(wth_bat_text_, buf);
    if (battery_icon != nullptr) {
        if (cal_bat_ != nullptr) lv_label_set_text(cal_bat_, battery_icon);
        if (wth_bat_ != nullptr) lv_label_set_text(wth_bat_, battery_icon);
    }
    if (wifi_icon != nullptr) {
        if (cal_wifi_ != nullptr) lv_label_set_text(cal_wifi_, wifi_icon);
        if (wth_wifi_ != nullptr) lv_label_set_text(wth_wifi_, wifi_icon);
    }
}

/* ---------- 对话状态刷新（三页共用，状态变化时才重绘） ---------- */
void CustomLcdDisplay::RefreshDeviceStateText() {
    if (!setup_ui_called_) return;
    auto state = Application::GetInstance().GetDeviceState();
    const char* short_text = "--";
    switch (state) {
        case kDeviceStateStarting: short_text = "启动"; break;
        case kDeviceStateWifiConfiguring: short_text = "配网"; break;
        case kDeviceStateIdle: short_text = "待机"; break;
        case kDeviceStateConnecting: short_text = "连接中"; break;
        case kDeviceStateListening: short_text = "聆听中"; break;
        case kDeviceStateSpeaking: short_text = "播报中"; break;
        case kDeviceStateNotifying: short_text = "通知中"; break;
        case kDeviceStateUpgrading: short_text = "升级中"; break;
        case kDeviceStateActivating: short_text = "激活中"; break;
        case kDeviceStateAudioTesting: short_text = "测试"; break;
        case kDeviceStateFatalError: short_text = "错误"; break;
        default: break;
    }
    static const char* s_last = nullptr;
    if (short_text == s_last) return;
    s_last = short_text;

    DisplayLockGuard lock(this);
    // 用 std::string 拼接，避开 snprintf 对 %s 长度的静态分析告警
    std::string full_text = std::string("状态：") + short_text;
    if (main_state_ != nullptr) lv_label_set_text(main_state_, full_text.c_str());
    if (cal_state_ != nullptr) lv_label_set_text(cal_state_, short_text);
    if (wth_state_ != nullptr) lv_label_set_text(wth_state_, short_text);
}

/* ---------- 状态栏总入口（Application 每秒调用） ---------- */
void CustomLcdDisplay::UpdateStatusBar(bool update_all) {
    // 基类：低电量弹窗 / 静音图标等系统行为
    LvglDisplay::UpdateStatusBar(update_all);

    if (!setup_ui_called_) return;

    time_t now = time(NULL);
    struct tm tm_now;
    localtime_r(&now, &tm_now);

    if (tm_now.tm_year + 1900 >= 2025) {
        int cur_min = tm_now.tm_hour * 60 + tm_now.tm_min;
        if (update_all || cur_min != last_minute_) {
            last_minute_ = cur_min;
            RefreshTimeLabels(&tm_now);
        }
    }

    static int seconds_counter = 0;
    if (update_all || seconds_counter++ % 30 == 0) {
        RefreshStatusIcons(update_all);
    }

    // 对话状态：每秒检查，仅在实际变化时才重绘对应区域
    RefreshDeviceStateText();
}
