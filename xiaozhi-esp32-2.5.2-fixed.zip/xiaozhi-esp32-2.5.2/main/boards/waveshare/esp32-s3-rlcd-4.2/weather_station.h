#ifndef BOARD_WEATHER_STATION_H
#define BOARD_WEATHER_STATION_H

#include <ctime>
#include <string>

// 天气数据（本溪市，来源 Open-Meteo 免费 API）
struct WeatherInfo {
    bool valid = false;

    // 当前实况（室外）
    int cur_temp = 0;          // °C
    int cur_hum = 0;           // %
    bool has_cur = false;

    // 5 日预报：[0]=昨天 [1]=今天 [2..4]=未来三天
    struct Daily {
        int day_of_month = 0;  // 公历"日"
        int weekday = 0;       // 0=周日 1..6
        int code = 0;          // WMO weather code
        int tmax = 0;          // °C
        int tmin = 0;          // °C
        int precip = 0;        // 降水概率 %
        bool valid = false;
    } daily[5];

    // 今天的辅助参数
    bool has_sun = false;
    int sunrise_h = 6, sunrise_m = 0;
    int sunset_h = 18, sunset_m = 0;
    int apparent = 0;          // 体感 °C
    int uv = 0;                // 紫外线指数
    bool has_wind = false;
    int wind_deg = 0;          // 风向角度
    float wind_speed = 0;      // m/s

    // 未来逐小时（每 2 小时 1 点，最多 6 点）
    int hours = 0;
    struct Hour {
        int hour = 0;          // 0..23
        int temp = 0;          // °C
        int precip = 0;        // %
    } hourly[6];
};

// WMO 天气代码 -> 中文短语（最多 3 字，避开不常用字）
const char* WeatherCodeText(int wmo_code);
// 风向角度 -> "北/东北/东/..."
const char* WindDirText(int deg);
// 风速(m/s) -> "x级"
const char* WindLevelText(float speed_ms);
// 紫外线指数 -> "弱/中等/强/很强/极强"
const char* UvLevelText(int uv);

class WeatherStation {
public:
    // display 通过 ApplyWeather 弱耦合（board 负责桥接），避免循环依赖
    using ApplyCallback = void (*)(const WeatherInfo&);

    explicit WeatherStation(ApplyCallback apply_cb) : apply_cb_(apply_cb) {}

    // 启动后台刷新任务（每 15 分钟一次，失败 30 秒后重试）
    void Start();

    // 请求立即刷新（例如切换到天气页且数据过期时）；仅操作全局状态，可为静态调用
    static void RequestAsync();

    // 查询城市坐标（含网络请求与解析，请在独立任务中调用，耗时可达数秒）
    static bool LookupCity(const std::string& city, double* lat, double* lon,
                           std::string* resolved_name);

    // 更新天气城市坐标并立即刷新（城市名用于天气页标题）
    static void SetLocation(double lat, double lon, const std::string& city);

    // 数据最后更新时间（0 表示尚无数据）
    static time_t LastUpdateAt();

private:
    static void TaskEntry(void* arg);
    void Run();
    ApplyCallback apply_cb_;
};

#endif  // BOARD_WEATHER_STATION_H
