#ifndef BOARD_WEATHER_STATION_H
#define BOARD_WEATHER_STATION_H

#include <ctime>
#include <string>

// 失败原因（用于在屏幕上显示，便于定位问题）
enum WeatherFailReason {
    kWeatherFailNone = 0,      // 无失败
    kWeatherFailNetwork = 1,   // 打开连接失败（DNS/TCP 等）
    kWeatherFailStatus = 2,    // 服务器返回非 200
    kWeatherFailParse = 3,     // 返回内容解析失败
    kWeatherFailCity = 4,      // 城市未找到
};

// 天气数据（来源：中国天气网 d1.weather.com.cn，国内权威实测数据）
struct WeatherInfo {
    bool valid = false;
    int fail_reason = kWeatherFailNone;  // 失败时的原因，供界面提示

    // 当前实况（室外）
    int cur_temp = 0;          // °C
    int cur_hum = 0;           // %
    bool has_cur = false;
    char cond_cur[20] = {0};   // 当前天气中文，如“晴”“多云”

    // 5 日预报：[0]=今天 [1]=明天 [2..4]=之后
    struct Daily {
        int day_of_month = 0;  // 公历“日”
        int weekday = 0;       // 0=周日 1..6
        int tmax = 0;          // °C
        int tmin = 0;          // °C
        int precip = 0;        // 降水概率 %（该接口无此项时保持 0）
        bool valid = false;
        char cond[20] = {0};   // 天气中文，如“晴”“小雪”
    } daily[5];

    // 今天的辅助参数
    bool has_sun = false;
    int sunrise_h = 6, sunrise_m = 0;
    int sunset_h = 18, sunset_m = 0;
    int apparent = 0;          // 体感 °C
    int uv = 0;                // 紫外线指数
    char uv_text[16] = {0};    // 紫外线文字，如“中等”
    bool has_wind = false;
    int wind_deg = 0;          // 风向角度
    float wind_speed = 0;      // m/s
    char wind_text[28] = {0};  // 如“西北风3级”
    char aqi_text[16] = {0};   // 如“AQI 24”

    // 逐日趋势（最多 5 点；每个点附带横轴标签）
    bool trend_is_daily = false;  // true 表示按天（最高温），false 表示逐小时
    int hours = 0;
    struct Hour {
        int hour = 0;          // 小时或日序号
        int temp = 0;          // °C
        int precip = 0;        // %
        char label[10] = {0};  // 横轴文字，如“今天”“周四”
    } hourly[6];
};

// 天气代码 -> 中文短语
const char* WeatherCodeText(int wmo_code);
// 风向角度 -> "北/东北/东/..."
const char* WindDirText(int deg);
// 风速(m/s) -> "x级"
const char* WindLevelText(float speed_ms);
// 紫外线指数 -> "弱/中等/强/很强/极强"
const char* UvLevelText(int uv);

class WeatherStation {
public:
    // display 通过 ApplyWeather 弱耦合（board 负责桥接），避免循环依赖
    using ApplyCallback = void (*)(const WeatherInfo&);

    explicit WeatherStation(ApplyCallback apply_cb) : apply_cb_(apply_cb) {}

    // 启动后台刷新任务（每 15 分钟一次，失败 30 秒后重试）
    void Start();

    // 请求立即刷新（例如切换到天气页且数据过期时）；仅操作全局状态，可为静态调用
    static void RequestAsync();

    // 查询城市：通过中国天气网城市搜索接口把中文城市名转为城市 ID。
    // 含网络请求，请在独立任务中调用。
    static bool LookupCity(const std::string& city, std::string* city_id,
                           std::string* resolved_name);

    // 设置天气城市（city_id 为中国天气网城市编号）
    static void SetCity(const std::string& city_id, const std::string& city);

    // 当前城市 ID（默认本溪 101070501）
    static std::string CurrentCityId();

    // 数据最后更新时间（0 表示尚无数据）
    static time_t LastUpdateAt();

    // 最近一次抓取的失败原因（WeatherFailReason，0 表示最近一次成功或尚未抓取）
    static int LastFailReason();

private:
    static void TaskEntry(void* arg);
    void Run();
    ApplyCallback apply_cb_;
};

#endif  // BOARD_WEATHER_STATION_H
