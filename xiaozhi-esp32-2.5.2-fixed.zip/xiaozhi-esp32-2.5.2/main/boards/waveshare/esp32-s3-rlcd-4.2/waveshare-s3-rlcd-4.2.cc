#include <esp_lcd_panel_vendor.h>
#include <driver/i2c_master.h>
#include <driver/spi_common.h>
#include <esp_log.h>
#include <freertos/FreeRTOS.h>
#include <freertos/task.h>

#include <cJSON.h>
#include <ctime>

#include "custom_lcd_display.h"
#include "wifi_board.h"
#include "application.h"
#include "button.h"
#include "config.h"
#include "codecs/box_audio_codec.h"
#include "wifi_station.h"
#include "mcp_server.h"
#include "lvgl.h"
#include "weather_station.h"

#define TAG "waveshare_rlcd_4_2"

// 板载 SHTC3 温湿度传感器（与音频 codec 共用 I2C 总线）
#define SHTC3_I2C_ADDR      0x70
#define SHTC3_READ_PERIOD_S 60

// 天气刷新触发阈值（秒）
#define WEATHER_STALE_S (25 * 60)

// 天气数据回显到屏幕（由天气线程调用，转发到主线程执行）
static void ApplyWeatherToDisplay(const WeatherInfo& info) {
    auto display = static_cast<CustomLcdDisplay*>(Board::GetInstance().GetDisplay());
    if (display == nullptr) return;
    Application::GetInstance().Schedule([display, info]() {
        display->ApplyWeather(info);
    });
}

class CustomBoard : public WifiBoard {
private:
    i2c_master_bus_handle_t i2c_bus_;
    i2c_master_dev_handle_t shtc3_ = nullptr;
    Button boot_button_;
    CustomLcdDisplay *display_;
    WeatherStation* weather_ = nullptr;
    adc_oneshot_unit_handle_t adc1_handle;
    adc_cali_handle_t cali_handle;
    bool vbat_status = 0;

    void InitializeI2c() {
        i2c_master_bus_config_t i2c_bus_cfg = {};
        i2c_bus_cfg.i2c_port = ESP32_I2C_HOST;
        i2c_bus_cfg.sda_io_num = AUDIO_CODEC_I2C_SDA_PIN;
        i2c_bus_cfg.scl_io_num = AUDIO_CODEC_I2C_SCL_PIN;
        i2c_bus_cfg.clk_source = I2C_CLK_SRC_DEFAULT;
        i2c_bus_cfg.glitch_ignore_cnt = 7;
        i2c_bus_cfg.intr_priority = 0;
        i2c_bus_cfg.trans_queue_depth = 0;
        i2c_bus_cfg.flags.enable_internal_pullup = 1;
        ESP_ERROR_CHECK(i2c_new_master_bus(&i2c_bus_cfg, &i2c_bus_));
    }

    void InitializeButtons() {
        boot_button_.OnClick([this]() {
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                EnterWifiConfigMode();
                return;
            }
            // 短按：切换 界面（主页 -> 日历 -> 天气 -> 主页）
            Application::GetInstance().Schedule([this]() {
                if (display_ == nullptr) return;
                display_->SwitchPage(+1);
                if (display_->current_page() == kPageWeather && weather_ != nullptr) {
                    time_t now = time(NULL);
                    if (WeatherStation::LastUpdateAt() + WEATHER_STALE_S < now) {
                        weather_->RequestAsync();
                    }
                }
            });
        });

        boot_button_.OnLongPress([this]() {
            auto& app = Application::GetInstance();
            if (app.GetDeviceState() == kDeviceStateStarting) {
                return;
            }
            // 长按：开始/结束语音对话
            app.ToggleChatState();
        });
    }

    void InitializeTools() {
        auto& mcp_server = McpServer::GetInstance();
        mcp_server.AddTool("self.disp.network", "重新配网", PropertyList(),
        [this](const PropertyList&) -> ReturnValue {
            EnterWifiConfigMode();
            return true;
        });

        // ===== 主界面工作信息（语音修改） =====
        mcp_server.AddTool("self.board.set_task",
            "设置主界面工作信息栏的当前工作任务名称。content 为要显示的工作任务，例如“巡检作业”，建议不超过 5 个汉字。",
            PropertyList({Property("content", kPropertyTypeString)}),
        [this](const PropertyList& properties) -> ReturnValue {
            std::string value = properties["content"].value<std::string>();
            if (value.empty()) {
                return std::string("内容不能为空");
            }
            Application::GetInstance().Schedule([this, value]() {
                if (display_ != nullptr) display_->SetWorkField(0, value);
            });
            return std::string("工作信息已更新为: ") + value;
        });

        mcp_server.AddTool("self.board.set_master",
            "设置主界面工作信息栏的负责人姓名。content 为负责人姓名。",
            PropertyList({Property("content", kPropertyTypeString)}),
        [this](const PropertyList& properties) -> ReturnValue {
            std::string value = properties["content"].value<std::string>();
            if (value.empty()) {
                return std::string("内容不能为空");
            }
            Application::GetInstance().Schedule([this, value]() {
                if (display_ != nullptr) display_->SetWorkField(1, value);
            });
            return std::string("负责人已更新为: ") + value;
        });

        mcp_server.AddTool("self.board.set_workers",
            "设置主界面工作信息栏的当班工作人员名单。content 为工作人员姓名，多人用顿号或空格分隔。",
            PropertyList({Property("content", kPropertyTypeString)}),
        [this](const PropertyList& properties) -> ReturnValue {
            std::string value = properties["content"].value<std::string>();
            if (value.empty()) {
                return std::string("内容不能为空");
            }
            Application::GetInstance().Schedule([this, value]() {
                if (display_ != nullptr) display_->SetWorkField(2, value);
            });
            return std::string("工作人员已更新为: ") + value;
        });

        mcp_server.AddTool("self.board.set_gas",
            "设置主界面工作信息栏的气体浓度数值。content 例如“12ppm”或“浓度正常”。",
            PropertyList({Property("content", kPropertyTypeString)}),
        [this](const PropertyList& properties) -> ReturnValue {
            std::string value = properties["content"].value<std::string>();
            if (value.empty()) {
                return std::string("内容不能为空");
            }
            Application::GetInstance().Schedule([this, value]() {
                if (display_ != nullptr) display_->SetWorkField(3, value);
            });
            return std::string("气体浓度已更新为: ") + value;
        });

        // ===== 备忘录（语音修改） =====
        mcp_server.AddTool("self.board.set_memo",
            "写入设备主界面的备忘录。content 为备忘录内容（最多显示 3 行，建议 27 个汉字以内，超长部分自动省略），传空字符串表示清空备忘录。该内容会掉电保存。",
            PropertyList({Property("content", kPropertyTypeString)}),
        [this](const PropertyList& properties) -> ReturnValue {
            std::string value = properties["content"].value<std::string>();
            Application::GetInstance().Schedule([this, value]() {
                if (display_ != nullptr) display_->SetMemoText(value);
            });
            if (value.empty()) {
                return std::string("备忘录已清空");
            }
            return std::string("备忘录已更新为: ") + value;
        });

        // ===== 语音切换界面 =====
        mcp_server.AddTool("self.board.switch_page",
            "切换屏幕显示页面。page 可选：next（切换到下一个页面）、main（主页）、calendar（日历页）、weather（天气页）。",
            PropertyList({Property("page", kPropertyTypeString, std::string("next"))}),
        [this](const PropertyList& properties) -> ReturnValue {
            std::string page = properties["page"].value<std::string>();
            int target = -1;
            if (page == "next") {
                Application::GetInstance().Schedule([this]() {
                    if (display_ != nullptr) display_->SwitchPage(+1);
                });
                return std::string("已切换到下一个页面");
            } else if (page == "main") {
                target = 0;
            } else if (page == "calendar") {
                target = 1;
            } else if (page == "weather") {
                target = 2;
            }
            if (target < 0) {
                return std::string("page 参数可选 next/main/calendar/weather");
            }
            int final_target = target;
            Application::GetInstance().Schedule([this, final_target]() {
                if (display_ != nullptr) display_->SwitchToPage(final_target);
            });
            static const char* names[3] = {"主页", "日历", "天气"};
            return std::string("已切换到") + names[final_target] + std::string("页面");
        });

        // ===== 查询当前信息 =====
        mcp_server.AddTool("self.board.get_info",
            "查询主界面当前显示的内容，包括工作任务、负责人、工作人员、气体浓度和备忘录。",
            PropertyList(),
        [this](const PropertyList&) -> ReturnValue {
            if (display_ == nullptr) {
                return std::string("屏幕尚未就绪");
            }
            cJSON* root = cJSON_CreateObject();
            cJSON_AddStringToObject(root, "task", display_->GetWorkField(0).c_str());
            cJSON_AddStringToObject(root, "master", display_->GetWorkField(1).c_str());
            cJSON_AddStringToObject(root, "workers", display_->GetWorkField(2).c_str());
            cJSON_AddStringToObject(root, "gas", display_->GetWorkField(3).c_str());
            cJSON_AddStringToObject(root, "memo", display_->GetMemoText().c_str());
            char* rendered = cJSON_PrintUnformatted(root);
            std::string result(rendered);
            cJSON_free(rendered);
            cJSON_Delete(root);
            return result;
        });
    }

    void InitializeLcdDisplay() {
        spi_display_config_t spi_config = {};
        spi_config.mosi = RLCD_MOSI_PIN;
        spi_config.scl = RLCD_SCK_PIN;
        spi_config.dc = RLCD_DC_PIN;
        spi_config.cs = RLCD_CS_PIN;
        spi_config.rst = RLCD_RST_PIN;
        display_ = new CustomLcdDisplay(NULL, NULL, RLCD_WIDTH,RLCD_HEIGHT,DISPLAY_OFFSET_X,DISPLAY_OFFSET_Y,DISPLAY_MIRROR_X,DISPLAY_MIRROR_Y,DISPLAY_SWAP_XY,spi_config);
    }

    // ===== SHTC3 温湿度传感器 =====
    void InitializeSensor() {
        i2c_device_config_t dev_cfg = {};
        dev_cfg.dev_addr_length = I2C_ADDR_BIT_LEN_7;
        dev_cfg.device_address = SHTC3_I2C_ADDR;
        dev_cfg.scl_speed_hz = 100000;
        esp_err_t err = i2c_master_bus_add_device(i2c_bus_, &dev_cfg, &shtc3_);
        if (err != ESP_OK) {
            ESP_LOGW(TAG, "SHTC3 add device failed: %s", esp_err_to_name(err));
            shtc3_ = nullptr;
            return;
        }
        ESP_LOGI(TAG, "SHTC3 initialized at 0x%02x", SHTC3_I2C_ADDR);
        xTaskCreate(SensorTaskEntry, "shtc3", 4096, this, 3, nullptr);
    }

    static uint8_t Shtc3Crc8(const uint8_t* data, int len) {
        uint8_t crc = 0xFF;
        for (int i = 0; i < len; i++) {
            crc ^= data[i];
            for (int b = 0; b < 8; b++) {
                crc = (crc & 0x80) ? (uint8_t)((crc << 1) ^ 0x31) : (uint8_t)(crc << 1);
            }
        }
        return crc;
    }

    bool ReadShtc3(float* temperature, float* humidity) {
        if (shtc3_ == nullptr) return false;
        uint8_t cmd_wakeup[2] = {0x35, 0x17};
        uint8_t cmd_measure[2] = {0x7C, 0xA2};
        uint8_t cmd_sleep[2] = {0xB0, 0x98};
        uint8_t data[6];

        if (i2c_master_transmit(shtc3_, cmd_wakeup, 2, 100) != ESP_OK) return false;
        vTaskDelay(pdMS_TO_TICKS(2));
        if (i2c_master_transmit(shtc3_, cmd_measure, 2, 100) != ESP_OK) return false;
        vTaskDelay(pdMS_TO_TICKS(20));
        esp_err_t err = i2c_master_receive(shtc3_, data, 6, 100);
        i2c_master_transmit(shtc3_, cmd_sleep, 2, 100);
        if (err != ESP_OK) return false;

        if (Shtc3Crc8(data, 2) != data[2] || Shtc3Crc8(data + 3, 2) != data[5]) {
            ESP_LOGW(TAG, "SHTC3 CRC check failed");
            return false;
        }

        uint16_t raw_t = (uint16_t)((data[0] << 8) | data[1]);
        uint16_t raw_h = (uint16_t)((data[3] << 8) | data[4]);
        *temperature = -45.0f + 175.0f * raw_t / 65535.0f;
        *humidity = 100.0f * raw_h / 65535.0f;
        return true;
    }

    static void SensorTaskEntry(void* arg) {
        auto* board = static_cast<CustomBoard*>(arg);
        vTaskDelay(pdMS_TO_TICKS(8000));  // 等待系统启动稳定
        float temperature = 0, humidity = 0;
        while (true) {
            if (board->ReadShtc3(&temperature, &humidity)) {
                ESP_LOGI(TAG, "SHTC3: %.1fC %.1f%%", temperature, humidity);
                auto* display = board->display_;
                Application::GetInstance().Schedule([display, temperature, humidity]() {
                    display->SetSensorData(temperature, humidity);
                });
            } else {
                ESP_LOGW(TAG, "SHTC3 read failed, keep last value");
            }
            vTaskDelay(pdMS_TO_TICKS(SHTC3_READ_PERIOD_S * 1000));
        }
    }

    // ===== 天气 =====
    void InitializeWeather() {
        weather_ = new WeatherStation(ApplyWeatherToDisplay);
        weather_->Start();
    }

    uint16_t BatterygetVoltage(void) {
        static bool initialized = false;
        static adc_oneshot_unit_handle_t adc_handle;
        static adc_cali_handle_t cali_handle = NULL;
        if (!initialized) {
            adc_oneshot_unit_init_cfg_t init_config = {
                .unit_id = ADC_UNIT_1,
            };
            adc_oneshot_new_unit(&init_config, &adc_handle);
    
            adc_oneshot_chan_cfg_t ch_config = {
                .atten = ADC_ATTEN_DB_12,
                .bitwidth = ADC_BITWIDTH_12,
            };
            adc_oneshot_config_channel(adc_handle, ADC_CHANNEL_3, &ch_config);
    
            adc_cali_curve_fitting_config_t cali_config = {
                .unit_id = ADC_UNIT_1,
                .atten = ADC_ATTEN_DB_12,
                .bitwidth = ADC_BITWIDTH_12,
            };
            if (adc_cali_create_scheme_curve_fitting(&cali_config, &cali_handle) == ESP_OK) {
                initialized = true;
            }
        }

        if (initialized) {
            int raw_value = 0;
            int raw_voltage = 0;
            int voltage = 0; // mV
            adc_oneshot_read(adc_handle, ADC_CHANNEL_3, &raw_value);
            adc_cali_raw_to_voltage(cali_handle, raw_value, &raw_voltage);
            voltage =  raw_voltage * 3;
            // ESP_LOGI(TAG, "voltage: %dmV", voltage);
            return (uint16_t)voltage;
        }

        return 0;
    }

    uint8_t BatterygetPercent() {
        int voltage = 0;
        for (uint8_t i = 0; i < 10; i++) {
            voltage += BatterygetVoltage();
        }

        voltage /= 10;
        int percent = (-1 * voltage * voltage + 9016 * voltage - 19189000) / 10000;
        percent = (percent > 100) ? 100 : (percent < 0) ? 0 : percent;
        // ESP_LOGI(TAG, "voltage: %dmV, percentage: %d%%", voltage, percent);
        return (uint8_t)percent;
    }

public:
    CustomBoard() : boot_button_(BOOT_BUTTON_GPIO, false, 1000) {    
        InitializeI2c();  
        InitializeButtons();     
        InitializeTools();
        InitializeLcdDisplay();
        InitializeSensor();
        InitializeWeather();
   }

    virtual AudioCodec* GetAudioCodec() override {
        static BoxAudioCodec audio_codec(
            i2c_bus_, 
            AUDIO_INPUT_SAMPLE_RATE, 
            AUDIO_OUTPUT_SAMPLE_RATE,
            AUDIO_I2S_GPIO_MCLK, 
            AUDIO_I2S_GPIO_BCLK, 
            AUDIO_I2S_GPIO_WS, 
            AUDIO_I2S_GPIO_DOUT, 
            AUDIO_I2S_GPIO_DIN,
            AUDIO_CODEC_PA_PIN, 
            AUDIO_CODEC_ES8311_ADDR, 
            AUDIO_CODEC_ES7210_ADDR, 
            AUDIO_INPUT_REFERENCE);
        return &audio_codec;
    }

    virtual Display* GetDisplay() override {
        return display_;
    }

    virtual bool GetBatteryLevel(int &level, bool& charging, bool& discharging) override {
        charging = false;
        discharging = !charging;
        level = (int)BatterygetPercent();

        return true;
    }
};

DECLARE_BOARD(CustomBoard);
